player beefywhisper stop
player beefywhisper move forward
player beefywhisper unsprint
player beefywhisper unsneak