execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player beefywhisper hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player beefywhisper hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player beefywhisper hotbar 9

#potting
player beefywhisper stop
player beefywhisper unsprint
player beefywhisper sneak
player beefywhisper look down
player beefywhisper use once