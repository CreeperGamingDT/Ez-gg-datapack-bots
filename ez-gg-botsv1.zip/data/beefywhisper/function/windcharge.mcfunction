execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player beefywhisper look at ^ ^ ^1

player beefywhisper hotbar 4
player beefywhisper use once
player beefywhisper jump once
