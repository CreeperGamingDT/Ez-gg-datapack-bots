tag @p[distance=0.001..,tag=!team1attack,tag=team1follow] add follow

execute if entity @s[tag=team1R] run tag @p[distance=0.001..,tag=!team1attack,tag=team1follow,tag=!team1R] add target
execute if entity @s[tag=team1R] unless entity @p[distance=0.001..,tag=team1attack] run tag @p[distance=0.001..,gamemode=survival,tag=!team1notattack,tag=!follow,tag=!team1R] add target
execute if entity @s[tag=team1R] run tag @p[distance=0.001..,gamemode=survival,tag=team1attack,tag=!follow,tag=!team1R] add target
execute unless entity @s[tag=team1R] run tag @p[distance=0.001..,tag=!team1attack,tag=team1follow] add target
execute unless entity @s[tag=team1R] unless entity @p[distance=0.001..,tag=team1attack] run tag @p[distance=0.001..,gamemode=survival,tag=!team1notattack,tag=!follow] add target
execute unless entity @s[tag=team1R] run tag @p[distance=0.001..,gamemode=survival,tag=team1attack,tag=!follow] add target


#execute as @p[distance=0.001..,gamemode=!survival,tag=!target] at @s if entity @s[tag=!target] run player chunkymeteor22 stop





execute if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={health=..8}] add gap
execute if entity @s[tag=mikearmyR3] if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={health=..12}] add gap
execute if entity @s[tag=mikearmyR2] if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={health=..14}] add gap
execute if entity @s[tag=mikearmyR2] if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={sat=..19}] add gap
execute if entity @s[tag=mikearmyR1] if items entity @s hotbar.5 minecraft:enchanted_golden_apple run tag @s[scores={health=..18}] add gap
execute if entity @s[tag=mikearmyR1] if items entity @s hotbar.5 minecraft:enchanted_golden_apple run tag @s[scores={sat=..19}] add gap
#*sat gap
#execute if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={sat=..19}] add gap

#haswater
execute if items entity @s hotbar.4 minecraft:water_bucket run tag @s[tag=!gap] add haswater
execute if items entity @s hotbar.4 minecraft:bucket run tag @s[tag=!gap] add haswater

#cobweb
execute if block ~0.3 ~ ~0.3 cobweb run tag @s[tag=!gap,tag=haswater] add inweb
execute if block ~-0.3 ~ ~0.3 cobweb run tag @s[tag=!gap,tag=haswater] add inweb
execute if block ~-0.3 ~ ~-0.3 cobweb run tag @s[tag=!gap,tag=haswater] add inweb
execute if block ~0.3 ~ ~-0.3 cobweb run tag @s[tag=!gap,tag=haswater] add inweb
execute if block ~ ~ ~ cobweb run tag @s[tag=!gap,scores={waterplacedelay=..1}] add inwebfull
execute if block ~ ~ ~ cobweb run tag @s[tag=!gap] add inweb
execute as @s[scores={waterplacedelay=..1},tag=team1] if data entity @s {Inventory:[{Slot:4b,id:"minecraft:bucket"}]} at @s run function chunkymeteor22:webout2
execute if data entity @s {Inventory:[{Slot:4b,id:"minecraft:bucket"}]} run execute as @e[tag=retrivewater_chunkymeteor22] at @s run player chunkymeteor22 look at ~ ~-49 ~

#normal
execute if entity @p[tag=target,distance=..2,tag=!follow] run tag @s[tag=!gap,tag=!inweb] add crit
#execute if entity @p[tag=target,distance=..2,tag=!follow] run tag @s[tag=!gap,tag=!inweb] add backward
execute if entity @p[tag=target,distance=2..] unless entity @p[tag=follow,distance=..6] run tag @s[tag=!crit,tag=!gap,tag=!inweb] add walk
execute if entity @p[tag=target,distance=4..,tag=!nosprintjumptoward] unless entity @p[tag=follow,distance=..10] run tag @s[tag=!crit,tag=!gap,tag=!inweb] add sprintjump

#abovenowalk
function players:sssabovenowalk

#water
execute if entity @p[tag=target] if block ~ ~-0.3 ~ water unless block ~ ~1.5 ~ water unless block ~ ~2 ~ water if entity @p[tag=target,dy=-50] run tag @s[tag=!gap] add watersneak
execute if entity @p[tag=target] if block ~ ~-0.3 ~ water unless entity @p[tag=target,dy=-50] run tag @s[tag=!gap,tag=!watersneak] add waterjump
execute if entity @p[tag=target] if block ~ ~-0.3 ~ water if block ~ ~-1 ~ water run tag @s[tag=!gap] add inwater

#skill
execute if entity @p[tag=target,distance=..3,tag=!follow] run tag @s[tag=!gap,tag=!sprintjump,tag=!inweb] add strafe
execute if entity @p[tag=target] run tag @s[tag=!gap,tag=!inweb] add hitcooldown

#regular hit
execute if entity @p[tag=target,distance=..2.3,tag=!follow] if entity @p[tag=target,distance=2.13..] if entity @s[scores={hit_cooldown=..9}] run tag @s[tag=!crit,tag=!gap,tag=!inweb] add combohit

#pot
execute if entity @p[tag=target,tag=!follow] unless entity @s[nbt={active_effects:[{id:"minecraft:speed"},{id:"minecraft:strength"},{id:"minecraft:fire_resistance"}]}] if items entity @s hotbar.* minecraft:splash_potion run tag @s[tag=!gap,tag=!crit,tag=!inwater,tag=!inweb] add pot

#pearl
execute if entity @p[tag=target,distance=20..,tag=!follow] if items entity @s hotbar.2 minecraft:ender_pearl unless entity @p[tag=target,nbt={Inventory:[{Slot:102b,id:"minecraft:elytra"}]}] run tag @s[tag=!crit,tag=!gap,tag=!inwater,tag=!pot] add pearl

#look
execute if entity @p[tag=target] if entity @s[tag=!pot,tag=!inweb,tag=!pearl] as @p[tag=target] at @s run player chunkymeteor22 look at ~ ~1 ~
execute if entity @p[tag=follow,distance=..6] if entity @s[tag=!pot,tag=!inweb,tag=!pearl] run player chunkymeteor22 stop


#social distancing
function players:checknearestside

execute if entity @s[tag=backward] run player chunkymeteor22 unsprint
execute if entity @s[tag=backward] run player chunkymeteor22 move backward
execute if entity @s[tag=walk] run function chunkymeteor22:walk
execute if entity @s[tag=hitcooldown] run function chunkymeteor22:hitcooldown
execute if entity @s[tag=pearl] run function chunkymeteor22:pearl
execute if entity @s[tag=walk] run function chunkymeteor22:jumpoverblock
execute if entity @s[tag=crit] run function chunkymeteor22:crit
execute if entity @s[tag=nearest_left] run player chunkymeteor22 move right
execute if entity @s[tag=nearest_right] run player chunkymeteor22 move left
execute if entity @s[tag=gap] run function chunkymeteor22:gap
execute if entity @s[tag=!gap] run attribute @s minecraft:movement_speed modifier remove gap_slowdown
execute if entity @s[tag=sprintjump] run player chunkymeteor22 jump
execute if entity @s[tag=sprintjump] run player chunkymeteor22 sprint
#should stop instant let go and press sprint hitting
execute if entity @s[tag=sprintjump] if score @s hit_cooldown matches 15.. run player chunkymeteor22 unsprint
execute if entity @s[tag=waterjump] run player chunkymeteor22 jump continuous
execute if entity @s[tag=waterjump] run player chunkymeteor22 unsneak
execute if entity @s[tag=watersneak] run player chunkymeteor22 sneak
execute if entity @s[tag=combohit] run player chunkymeteor22 attack once
execute if entity @s[tag=combohit] run scoreboard players set @s hit 1
#execute if entity @s[tag=strafe] run function chunkymeteor22:strafe
execute if entity @s[tag=pot] run function chunkymeteor22:checkandpot
execute if entity @s[tag=inweb] run function chunkymeteor22:webout






tag @p[tag=target] remove target
tag @p[tag=follow] remove follow