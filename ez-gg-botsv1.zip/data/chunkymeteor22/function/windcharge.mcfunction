execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player chunkymeteor22 look at ^ ^ ^1

player chunkymeteor22 hotbar 4
player chunkymeteor22 use once
player chunkymeteor22 jump once
