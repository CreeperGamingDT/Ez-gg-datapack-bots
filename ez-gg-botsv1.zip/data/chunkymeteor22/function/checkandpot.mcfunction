execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player chunkymeteor22 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player chunkymeteor22 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player chunkymeteor22 hotbar 9

#potting
player chunkymeteor22 stop
player chunkymeteor22 unsprint
player chunkymeteor22 sneak
player chunkymeteor22 look down
player chunkymeteor22 use once