player chunkymeteor22 stop
player chunkymeteor22 jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player chunkymeteor22 attack once
tag @s add playcriteffectperson
function players:playcriteffect
