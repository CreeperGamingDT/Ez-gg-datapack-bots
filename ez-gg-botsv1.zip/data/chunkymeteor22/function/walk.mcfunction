player chunkymeteor22 stop
player chunkymeteor22 move forward
player chunkymeteor22 unsprint
player chunkymeteor22 unsneak