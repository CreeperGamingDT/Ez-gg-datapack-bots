execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player bitspectreout look at ^ ^ ^1

player bitspectreout hotbar 4
player bitspectreout use once
player bitspectreout jump once
