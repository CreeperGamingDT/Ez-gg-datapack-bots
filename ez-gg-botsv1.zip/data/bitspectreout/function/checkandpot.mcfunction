execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player bitspectreout hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player bitspectreout hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player bitspectreout hotbar 9

#potting
player bitspectreout stop
player bitspectreout unsprint
player bitspectreout sneak
player bitspectreout look down
player bitspectreout use once