player bitspectreout stop
player bitspectreout move forward
player bitspectreout unsprint
player bitspectreout unsneak