execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player breadcrumbtoast hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player breadcrumbtoast hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player breadcrumbtoast hotbar 9

#potting
player breadcrumbtoast stop
player breadcrumbtoast unsprint
player breadcrumbtoast sneak
player breadcrumbtoast look down
player breadcrumbtoast use once