player breadcrumbtoast stop
player breadcrumbtoast move forward
player breadcrumbtoast unsprint
player breadcrumbtoast unsneak