# Summon an armor stand
summon armor_stand ~ ~ ~ {Tags:["yawonly"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

# Copy yaw from nearest player to armor stand
execute store result entity @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] Rotation[0] float 1 run data get entity @s Rotation[0]

execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s unless block ^ ^ ^1.5 #replaceable unless block ^ ^ ^0.8 #replaceable run player breadcrumbtoast jump once

execute if items entity @s hotbar.* minecraft:wind_charge as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s positioned ~ ~1 ~ unless block ^ ^ ^1.5 #replaceable unless block ^ ^ ^0.8 #replaceable run function breadcrumbtoast:windcharge



kill @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly]
