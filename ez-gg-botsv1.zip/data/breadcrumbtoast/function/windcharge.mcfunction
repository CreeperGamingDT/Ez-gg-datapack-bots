execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player breadcrumbtoast look at ^ ^ ^1

player breadcrumbtoast hotbar 4
player breadcrumbtoast use once
player breadcrumbtoast jump once
