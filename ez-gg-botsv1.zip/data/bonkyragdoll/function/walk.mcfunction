player bonkyragdoll stop
player bonkyragdoll move forward
player bonkyragdoll unsprint
player bonkyragdoll unsneak