execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player bonkyragdoll hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player bonkyragdoll hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player bonkyragdoll hotbar 9

#potting
player bonkyragdoll stop
player bonkyragdoll unsprint
player bonkyragdoll sneak
player bonkyragdoll look down
player bonkyragdoll use once