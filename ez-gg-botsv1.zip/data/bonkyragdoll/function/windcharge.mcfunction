execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player bonkyragdoll look at ^ ^ ^1

player bonkyragdoll hotbar 4
player bonkyragdoll use once
player bonkyragdoll jump once
