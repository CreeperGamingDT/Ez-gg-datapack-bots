execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player controlaltf4_ look at ^ ^ ^1

player controlaltf4_ hotbar 4
player controlaltf4_ use once
player controlaltf4_ jump once
