player controlaltf4_ stop
player controlaltf4_ move forward
player controlaltf4_ unsprint
player controlaltf4_ unsneak