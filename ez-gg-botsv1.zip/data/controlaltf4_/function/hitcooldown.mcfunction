execute if entity @s[scores={hit_cooldown=..9}] run player controlaltf4_ hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player controlaltf4_ hotbar 2