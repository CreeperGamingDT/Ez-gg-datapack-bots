player controlaltf4_ stop
player controlaltf4_ jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player controlaltf4_ attack once
tag @s add playcriteffectperson
function players:playcriteffect
