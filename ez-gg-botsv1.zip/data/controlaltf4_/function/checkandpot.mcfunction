execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player controlaltf4_ hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player controlaltf4_ hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player controlaltf4_ hotbar 9

#potting
player controlaltf4_ stop
player controlaltf4_ unsprint
player controlaltf4_ sneak
player controlaltf4_ look down
player controlaltf4_ use once