player aw8s0mket2hup38 stop
player aw8s0mket2hup38 move forward
player aw8s0mket2hup38 unsprint
player aw8s0mket2hup38 unsneak