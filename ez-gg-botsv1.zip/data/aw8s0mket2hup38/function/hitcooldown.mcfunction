execute if entity @s[scores={hit_cooldown=..9}] run player aw8s0mket2hup38 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player aw8s0mket2hup38 hotbar 2