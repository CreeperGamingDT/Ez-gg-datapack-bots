execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player aw8s0mket2hup38 look at ^ ^ ^1

player aw8s0mket2hup38 hotbar 4
player aw8s0mket2hup38 use once
player aw8s0mket2hup38 jump once
