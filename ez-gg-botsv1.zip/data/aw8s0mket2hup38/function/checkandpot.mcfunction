execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player aw8s0mket2hup38 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player aw8s0mket2hup38 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player aw8s0mket2hup38 hotbar 9

#potting
player aw8s0mket2hup38 stop
player aw8s0mket2hup38 unsprint
player aw8s0mket2hup38 sneak
player aw8s0mket2hup38 look down
player aw8s0mket2hup38 use once