execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player evilsmileyhehe hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player evilsmileyhehe hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player evilsmileyhehe hotbar 9

#potting
player evilsmileyhehe stop
player evilsmileyhehe unsprint
player evilsmileyhehe sneak
player evilsmileyhehe look down
player evilsmileyhehe use once