player burpleminion stop
player burpleminion move forward
player burpleminion unsprint
player burpleminion unsneak