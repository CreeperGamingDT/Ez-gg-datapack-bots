execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player burpleminion hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player burpleminion hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player burpleminion hotbar 9

#potting
player burpleminion stop
player burpleminion unsprint
player burpleminion sneak
player burpleminion look down
player burpleminion use once