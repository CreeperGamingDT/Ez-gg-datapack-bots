execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player burpleminion look at ^ ^ ^1

player burpleminion hotbar 4
player burpleminion use once
player burpleminion jump once
