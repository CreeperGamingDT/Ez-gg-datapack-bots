player asdfghjkl8735417 stop
player asdfghjkl8735417 move forward
player asdfghjkl8735417 unsprint
player asdfghjkl8735417 unsneak