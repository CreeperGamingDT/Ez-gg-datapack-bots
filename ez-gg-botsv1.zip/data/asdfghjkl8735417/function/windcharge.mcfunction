execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player asdfghjkl8735417 look at ^ ^ ^1

player asdfghjkl8735417 hotbar 4
player asdfghjkl8735417 use once
player asdfghjkl8735417 jump once
