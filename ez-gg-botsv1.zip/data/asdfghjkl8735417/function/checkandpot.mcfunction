execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player asdfghjkl8735417 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player asdfghjkl8735417 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player asdfghjkl8735417 hotbar 9

#potting
player asdfghjkl8735417 stop
player asdfghjkl8735417 unsprint
player asdfghjkl8735417 sneak
player asdfghjkl8735417 look down
player asdfghjkl8735417 use once