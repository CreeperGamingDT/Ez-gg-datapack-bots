execute if entity @s[scores={hit_cooldown=..9}] run player asdfghjkl8735417 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player asdfghjkl8735417 hotbar 2