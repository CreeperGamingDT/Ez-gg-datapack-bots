#haswater
execute if entity @s[tag=haswater,scores={waterplacedelay=..8},tag=team1] run player asdfghjkl8735417 hotbar 5
execute if entity @s[tag=haswater,scores={waterplacedelay=..8},tag=team1] run player asdfghjkl8735417 unsprint
execute if entity @s[tag=haswater,scores={waterplacedelay=..8},tag=team1] run player asdfghjkl8735417 look down

#else
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=0},tag=team1] as @e[tag=fakebreak.asdfghjkl8735417] at @s positioned ~ ~-1 ~ run function players:setblockinsideair
execute if entity @s[scores={waterplacedelay=0},tag=team1] run kill @e[tag=fakebreak.asdfghjkl8735417]
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=0},tag=team1] run player asdfghjkl8735417 stop
#execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=0},tag=team1] run say iwi

execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run player asdfghjkl8735417 hotbar 1
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run player asdfghjkl8735417 stop
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run player asdfghjkl8735417 unsprint
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run player asdfghjkl8735417 unsneak
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run player asdfghjkl8735417 look down
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run summon armor_stand ~ ~1.5 ~ {Tags:["fakebreak.asdfghjkl8735417"],NoGravity:1b,Invisible:1b}
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run player asdfghjkl8735417 attack once
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=14},tag=team1] run player asdfghjkl8735417 attack interval 8
#has to be a multiple of 8 for some reason
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=..-1},tag=team1] run scoreboard players set @s waterplacedelay 16
execute if entity @s[tag=!haswater,tag=inwebfull,scores={waterplacedelay=0..},tag=team1] run playsound minecraft:block.cobweb.hit block @a ~ ~ ~ 1 0.3 0

execute as @e[tag=fakebreak.asdfghjkl8735417] at @s run attribute @s minecraft:scale base set 0.01




execute as @s[scores={waterplacedelay=..1},tag=team1] if data entity @s {Inventory:[{Slot:4b,id:"minecraft:water_bucket"}]} at @s run function asdfghjkl8735417:webout1

