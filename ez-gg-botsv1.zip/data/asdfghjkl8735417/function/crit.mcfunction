player asdfghjkl8735417 stop
player asdfghjkl8735417 jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player asdfghjkl8735417 attack once
tag @s add playcriteffectperson
function players:playcriteffect
