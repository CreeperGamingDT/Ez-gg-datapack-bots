execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player 8bit__feral look at ^ ^ ^1

player 8bit__feral hotbar 4
player 8bit__feral use once
player 8bit__feral jump once
