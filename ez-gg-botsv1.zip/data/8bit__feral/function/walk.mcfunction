player 8bit__feral stop
player 8bit__feral move forward
player 8bit__feral unsprint
player 8bit__feral unsneak