execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player 8bit__feral hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player 8bit__feral hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player 8bit__feral hotbar 9

#potting
player 8bit__feral stop
player 8bit__feral unsprint
player 8bit__feral sneak
player 8bit__feral look down
player 8bit__feral use once