player 8bit__feral stop
player 8bit__feral jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player 8bit__feral attack once
tag @s add playcriteffectperson
function players:playcriteffect
