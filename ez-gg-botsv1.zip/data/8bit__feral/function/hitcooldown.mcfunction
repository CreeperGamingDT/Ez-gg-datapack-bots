execute if entity @s[scores={hit_cooldown=..9}] run player 8bit__feral hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player 8bit__feral hotbar 2