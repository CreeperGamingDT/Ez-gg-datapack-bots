player bird_four_four_2 stop
player bird_four_four_2 move forward
player bird_four_four_2 unsprint
player bird_four_four_2 unsneak