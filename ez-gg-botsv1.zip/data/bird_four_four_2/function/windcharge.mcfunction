execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player bird_four_four_2 look at ^ ^ ^1

player bird_four_four_2 hotbar 4
player bird_four_four_2 use once
player bird_four_four_2 jump once
