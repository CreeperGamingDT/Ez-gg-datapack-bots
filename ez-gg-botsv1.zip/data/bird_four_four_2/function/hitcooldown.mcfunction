execute if entity @s[scores={hit_cooldown=..9}] run player bird_four_four_2 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player bird_four_four_2 hotbar 2