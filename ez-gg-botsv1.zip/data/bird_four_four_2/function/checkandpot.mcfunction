execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player bird_four_four_2 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player bird_four_four_2 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player bird_four_four_2 hotbar 9

#potting
player bird_four_four_2 stop
player bird_four_four_2 unsprint
player bird_four_four_2 sneak
player bird_four_four_2 look down
player bird_four_four_2 use once