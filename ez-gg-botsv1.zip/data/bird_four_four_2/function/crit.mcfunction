player bird_four_four_2 stop
player bird_four_four_2 jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player bird_four_four_2 attack once
tag @s add playcriteffectperson
function players:playcriteffect
