player cryptocrumpet stop
player cryptocrumpet move forward
player cryptocrumpet unsprint
player cryptocrumpet unsneak