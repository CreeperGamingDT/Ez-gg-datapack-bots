execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player cryptocrumpet hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player cryptocrumpet hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player cryptocrumpet hotbar 9

#potting
player cryptocrumpet stop
player cryptocrumpet unsprint
player cryptocrumpet sneak
player cryptocrumpet look down
player cryptocrumpet use once