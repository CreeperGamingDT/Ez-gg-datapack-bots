execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player cryptocrumpet look at ^ ^ ^1

player cryptocrumpet hotbar 4
player cryptocrumpet use once
player cryptocrumpet jump once
