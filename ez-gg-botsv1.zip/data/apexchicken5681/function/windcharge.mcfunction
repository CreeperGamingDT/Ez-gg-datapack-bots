execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player apexchicken5681 look at ^ ^ ^1

player apexchicken5681 hotbar 4
player apexchicken5681 use once
player apexchicken5681 jump once
