player apexchicken5681 stop
player apexchicken5681 move forward
player apexchicken5681 unsprint
player apexchicken5681 unsneak