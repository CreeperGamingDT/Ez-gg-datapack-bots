execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player apexchicken5681 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player apexchicken5681 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player apexchicken5681 hotbar 9

#potting
player apexchicken5681 stop
player apexchicken5681 unsprint
player apexchicken5681 sneak
player apexchicken5681 look down
player apexchicken5681 use once