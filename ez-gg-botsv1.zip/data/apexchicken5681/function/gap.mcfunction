player apexchicken5681 unsprint
attribute @s minecraft:movement_speed modifier add gap_slowdown -0.9 add_multiplied_total
execute unless data entity @s {SelectedItem:{id:"minecraft:golden_apple"}} unless data entity @s {SelectedItem:{id:"minecraft:enchanted_golden_apple"}} run player apexchicken5681 use continuous
execute unless data entity @s {SelectedItem:{id:"minecraft:golden_apple"}} unless data entity @s {SelectedItem:{id:"minecraft:enchanted_golden_apple"}} run player apexchicken5681 hotbar 6
execute if entity @p[tag=target,distance=..3.4] run player apexchicken5681 move backward
