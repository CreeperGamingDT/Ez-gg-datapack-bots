execute if entity @s[scores={hit_cooldown=..9}] run player apexchicken5681 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player apexchicken5681 hotbar 2