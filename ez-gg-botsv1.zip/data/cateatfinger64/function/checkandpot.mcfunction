execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player cateatfinger64 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player cateatfinger64 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player cateatfinger64 hotbar 9

#potting
player cateatfinger64 stop
player cateatfinger64 unsprint
player cateatfinger64 sneak
player cateatfinger64 look down
player cateatfinger64 use once