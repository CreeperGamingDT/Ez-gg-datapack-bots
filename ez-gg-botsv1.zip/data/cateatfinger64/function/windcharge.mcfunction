execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player cateatfinger64 look at ^ ^ ^1

player cateatfinger64 hotbar 4
player cateatfinger64 use once
player cateatfinger64 jump once