player cateatfinger64 stop
player cateatfinger64 move forward
player cateatfinger64 unsprint
player cateatfinger64 unsneak