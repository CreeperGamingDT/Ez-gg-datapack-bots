setblock ~ ~1 ~ water
item replace entity @s hotbar.4 with bucket
scoreboard players set @s waterplacedelay 16

summon armor_stand ~ ~50 ~ {Tags:["retrivewater_cateatfinger64"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}