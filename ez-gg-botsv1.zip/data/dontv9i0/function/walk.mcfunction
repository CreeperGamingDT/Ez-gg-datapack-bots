player dontv9i0 stop
player dontv9i0 move forward
player dontv9i0 unsprint
player dontv9i0 unsneak