execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player dontv9i0 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player dontv9i0 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player dontv9i0 hotbar 9

#potting
player dontv9i0 stop
player dontv9i0 unsprint
player dontv9i0 sneak
player dontv9i0 look down
player dontv9i0 use once