execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player dontv9i0 look at ^ ^ ^1

player dontv9i0 hotbar 4
player dontv9i0 use once
player dontv9i0 jump once
