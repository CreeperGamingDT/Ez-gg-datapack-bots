execute if entity @s[scores={hit_cooldown=..9}] run player dontv9i0 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player dontv9i0 hotbar 2