player ehiwir_ng stop
player ehiwir_ng move forward
player ehiwir_ng unsprint
player ehiwir_ng unsneak