execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player ehiwir_ng look at ^ ^ ^1

player ehiwir_ng hotbar 4
player ehiwir_ng use once
player ehiwir_ng jump once
