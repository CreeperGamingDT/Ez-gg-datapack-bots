player ehiwir_ng stop
player ehiwir_ng jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player ehiwir_ng attack once
tag @s add playcriteffectperson
function players:playcriteffect
