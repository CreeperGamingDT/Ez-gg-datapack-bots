execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player ehiwir_ng hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player ehiwir_ng hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player ehiwir_ng hotbar 9

#potting
player ehiwir_ng stop
player ehiwir_ng unsprint
player ehiwir_ng sneak
player ehiwir_ng look down
player ehiwir_ng use once