player axolotlsprinter stop
player axolotlsprinter move forward
player axolotlsprinter unsprint
player axolotlsprinter unsneak