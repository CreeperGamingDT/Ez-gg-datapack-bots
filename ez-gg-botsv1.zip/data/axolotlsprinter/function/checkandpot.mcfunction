execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player axolotlsprinter hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player axolotlsprinter hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player axolotlsprinter hotbar 9

#potting
player axolotlsprinter stop
player axolotlsprinter unsprint
player axolotlsprinter sneak
player axolotlsprinter look down
player axolotlsprinter use once