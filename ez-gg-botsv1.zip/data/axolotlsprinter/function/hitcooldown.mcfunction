execute if entity @s[scores={hit_cooldown=..9}] run player axolotlsprinter hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player axolotlsprinter hotbar 2