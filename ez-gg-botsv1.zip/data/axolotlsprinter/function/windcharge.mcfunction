execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player axolotlsprinter look at ^ ^ ^1

player axolotlsprinter hotbar 4
player axolotlsprinter use once
player axolotlsprinter jump once
