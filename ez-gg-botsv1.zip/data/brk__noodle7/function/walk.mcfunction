player brk__noodle7 stop
player brk__noodle7 move forward
player brk__noodle7 unsprint
player brk__noodle7 unsneak