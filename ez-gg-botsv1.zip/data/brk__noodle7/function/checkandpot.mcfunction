execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player brk__noodle7 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player brk__noodle7 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player brk__noodle7 hotbar 9

#potting
player brk__noodle7 stop
player brk__noodle7 unsprint
player brk__noodle7 sneak
player brk__noodle7 look down
player brk__noodle7 use once