execute if entity @s[scores={hit_cooldown=..9}] run player brk__noodle7 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player brk__noodle7 hotbar 2