execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player brk__noodle7 look at ^ ^ ^1

player brk__noodle7 hotbar 4
player brk__noodle7 use once
player brk__noodle7 jump once
