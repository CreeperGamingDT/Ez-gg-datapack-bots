execute as @e[tag=retrivewater_defenderstrate3] at @s run fill ~-2 ~-48 ~-2 ~2 ~-50.5 ~2 air replace water[level=0]

item replace entity @s hotbar.4 with water_bucket
scoreboard players set @s waterplacedelay 15

kill @e[tag=retrivewater_defenderstrate3]