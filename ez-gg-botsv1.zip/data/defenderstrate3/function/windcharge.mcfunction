execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player defenderstrate3 look at ^ ^ ^1

player defenderstrate3 hotbar 4
player defenderstrate3 use once
player defenderstrate3 jump once
