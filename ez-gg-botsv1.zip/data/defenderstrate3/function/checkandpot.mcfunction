execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player defenderstrate3 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player defenderstrate3 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player defenderstrate3 hotbar 9

#potting
player defenderstrate3 stop
player defenderstrate3 unsprint
player defenderstrate3 sneak
player defenderstrate3 look down
player defenderstrate3 use once