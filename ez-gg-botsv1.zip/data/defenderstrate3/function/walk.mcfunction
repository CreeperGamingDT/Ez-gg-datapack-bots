player defenderstrate3 stop
player defenderstrate3 move forward
player defenderstrate3 unsprint
player defenderstrate3 unsneak