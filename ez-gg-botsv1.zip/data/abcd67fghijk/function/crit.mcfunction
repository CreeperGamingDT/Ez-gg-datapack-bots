player abcd67fghijk stop
player abcd67fghijk jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player abcd67fghijk attack once
tag @s add playcriteffectperson
function players:playcriteffect
