execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player abcd67fghijk look at ^ ^ ^1

player abcd67fghijk hotbar 4
player abcd67fghijk use once
player abcd67fghijk jump once
