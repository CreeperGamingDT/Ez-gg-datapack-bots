player abcd67fghijk stop
player abcd67fghijk move forward
player abcd67fghijk unsprint
player abcd67fghijk unsneak