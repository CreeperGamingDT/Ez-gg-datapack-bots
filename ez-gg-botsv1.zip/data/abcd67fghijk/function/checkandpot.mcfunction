execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player abcd67fghijk hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player abcd67fghijk hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player abcd67fghijk hotbar 9

#potting
player abcd67fghijk stop
player abcd67fghijk unsprint
player abcd67fghijk sneak
player abcd67fghijk look down
player abcd67fghijk use once