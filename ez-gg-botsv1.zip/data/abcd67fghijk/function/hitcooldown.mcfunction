execute if entity @s[scores={hit_cooldown=..9}] run player abcd67fghijk hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player abcd67fghijk hotbar 2