player crnchy_f33t stop
player crnchy_f33t jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player crnchy_f33t attack once
tag @s add playcriteffectperson
function players:playcriteffect
