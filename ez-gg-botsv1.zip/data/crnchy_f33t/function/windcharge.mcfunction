execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player crnchy_f33t look at ^ ^ ^1

player crnchy_f33t hotbar 4
player crnchy_f33t use once
player crnchy_f33t jump once
