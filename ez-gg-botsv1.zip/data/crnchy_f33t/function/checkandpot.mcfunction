execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player crnchy_f33t hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player crnchy_f33t hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player crnchy_f33t hotbar 9

#potting
player crnchy_f33t stop
player crnchy_f33t unsprint
player crnchy_f33t sneak
player crnchy_f33t look down
player crnchy_f33t use once