player crnchy_f33t stop
player crnchy_f33t move forward
player crnchy_f33t unsprint
player crnchy_f33t unsneak