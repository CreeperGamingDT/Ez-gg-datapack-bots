execute if entity @s[scores={hit_cooldown=..9}] run player crnchy_f33t hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player crnchy_f33t hotbar 2