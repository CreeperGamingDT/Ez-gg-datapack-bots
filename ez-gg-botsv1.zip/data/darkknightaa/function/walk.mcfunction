player darkknightaa stop
player darkknightaa move forward
player darkknightaa unsprint
player darkknightaa unsneak