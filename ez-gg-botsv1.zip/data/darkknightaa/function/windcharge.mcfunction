execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player darkknightaa look at ^ ^ ^1

player darkknightaa hotbar 4
player darkknightaa use once
player darkknightaa jump once
