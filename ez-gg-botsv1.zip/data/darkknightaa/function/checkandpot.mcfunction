execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player darkknightaa hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player darkknightaa hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player darkknightaa hotbar 9

#potting
player darkknightaa stop
player darkknightaa unsprint
player darkknightaa sneak
player darkknightaa look down
player darkknightaa use once