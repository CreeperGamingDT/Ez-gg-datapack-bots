player darkknightaa stop
player darkknightaa jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player darkknightaa attack once
tag @s add playcriteffectperson
function players:playcriteffect
