execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player br34dbucket_x look at ^ ^ ^1

player br34dbucket_x hotbar 4
player br34dbucket_x use once
player br34dbucket_x jump once
