execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player br34dbucket_x hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player br34dbucket_x hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player br34dbucket_x hotbar 9

#potting
player br34dbucket_x stop
player br34dbucket_x unsprint
player br34dbucket_x sneak
player br34dbucket_x look down
player br34dbucket_x use once