player br34dbucket_x stop
player br34dbucket_x move forward
player br34dbucket_x unsprint
player br34dbucket_x unsneak