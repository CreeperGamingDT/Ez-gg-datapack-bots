player chesewhopper stop
player chesewhopper move forward
player chesewhopper unsprint
player chesewhopper unsneak