execute if entity @s[scores={hit_cooldown=..9}] run player chesewhopper hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player chesewhopper hotbar 2