execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player chesewhopper look at ^ ^ ^1

player chesewhopper hotbar 4
player chesewhopper use once
player chesewhopper jump once
