



tag @p[distance=0.001..,tag=!team1attack,tag=team1follow] add follow

execute as chesewhopper at @s if entity @s[tag=team1R] run tag @p[distance=0.001..,gamemode=survival,tag=!team1R,tag=!team1notattack,tag=!team1] add target
execute as chesewhopper at @s if entity @s[tag=!team1R] run tag @p[distance=0.001..,gamemode=survival,tag=team1R,tag=!team1notattack,tag=!team1] add target

execute as chesewhopper at @s if entity @s[tag=!randaaloopdelay] run function chesewhopper:conditions

execute as chesewhopper if entity @s[scores={team1indcount=0..1}] run schedule function chesewhopper:aaloop 2t replace
execute as chesewhopper if entity @s[scores={team1indcount=1..3}] run schedule function chesewhopper:aaloop 3t replace
execute as chesewhopper if entity @s[scores={team1indcount=3..7}] run schedule function chesewhopper:aaloop 4t replace
execute as chesewhopper if entity @s[scores={team1indcount=7..15}] run schedule function chesewhopper:aaloop 6t replace
execute as chesewhopper if entity @s[scores={team1indcount=15..20}] run schedule function chesewhopper:aaloop 10t replace
execute as chesewhopper if entity @s[scores={team1indcount=20..}] run schedule function chesewhopper:aaloop 15t replace

execute as @p[tag=target] if entity @s[tag=overideaaloop2t] as chesewhopper run schedule function chesewhopper:aaloop 2t replace
execute as @p[tag=target] if entity @s[tag=overideaaloop3t] as chesewhopper run schedule function chesewhopper:aaloop 3t replace
execute as @p[tag=target] if entity @s[tag=overideaaloop4t] as chesewhopper run schedule function chesewhopper:aaloop 4t replace
execute as @p[tag=target] if entity @s[tag=overideaaloop5t] as chesewhopper run schedule function chesewhopper:aaloop 5t replace
execute as @p[tag=target] if entity @s[tag=overideaaloop6t] as chesewhopper run schedule function chesewhopper:aaloop 6t replace

execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random0"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random1"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random2"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random4"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random5"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random6"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random7"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random8"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
execute if entity @s[tag=randaaloopdelay] run summon armor_stand ~ ~ ~ {Tags:["random","random9"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random1] run schedule function chesewhopper:aaloop 1t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run schedule function chesewhopper:aaloop 12t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random3] run schedule function chesewhopper:aaloop 24t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random4] run schedule function chesewhopper:aaloop 36t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random5] run schedule function chesewhopper:aaloop 48t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random6] run schedule function chesewhopper:aaloop 60t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random7] run schedule function chesewhopper:aaloop 72t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random8] run schedule function chesewhopper:aaloop 84t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random9] run schedule function chesewhopper:aaloop 108t replace
execute if entity @s[tag=randaaloopdelay] run execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random0] run schedule function chesewhopper:aaloop 120t replace

kill @e[tag=random]
tag @e[tag=target] remove target
tag @e[tag=follow] remove follow