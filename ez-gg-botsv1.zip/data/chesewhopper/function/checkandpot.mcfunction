execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player chesewhopper hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player chesewhopper hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player chesewhopper hotbar 9

#potting
player chesewhopper stop
player chesewhopper unsprint
player chesewhopper sneak
player chesewhopper look down
player chesewhopper use once