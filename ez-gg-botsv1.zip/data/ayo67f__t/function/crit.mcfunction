player ayo67f__t stop
player ayo67f__t jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player ayo67f__t attack once
tag @s add playcriteffectperson
function players:playcriteffect
