execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player ayo67f__t look at ^ ^ ^1

player ayo67f__t hotbar 4
player ayo67f__t use once
player ayo67f__t jump once
