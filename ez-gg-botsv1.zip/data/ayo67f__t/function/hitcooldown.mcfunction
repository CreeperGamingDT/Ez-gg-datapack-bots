execute if entity @s[scores={hit_cooldown=..9}] run player ayo67f__t hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player ayo67f__t hotbar 2