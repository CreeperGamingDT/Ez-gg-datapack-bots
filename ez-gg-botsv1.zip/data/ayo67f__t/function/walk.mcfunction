player ayo67f__t stop
player ayo67f__t move forward
player ayo67f__t unsprint
player ayo67f__t unsneak