execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player ayo67f__t hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player ayo67f__t hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player ayo67f__t hotbar 9

#potting
player ayo67f__t stop
player ayo67f__t unsprint
player ayo67f__t sneak
player ayo67f__t look down
player ayo67f__t use once