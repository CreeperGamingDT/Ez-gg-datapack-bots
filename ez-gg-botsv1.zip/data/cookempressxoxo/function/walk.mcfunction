player cookempressxoxo stop
player cookempressxoxo move forward
player cookempressxoxo unsprint
player cookempressxoxo unsneak