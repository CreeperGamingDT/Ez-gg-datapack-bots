execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player cookempressxoxo hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player cookempressxoxo hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player cookempressxoxo hotbar 9

#potting
player cookempressxoxo stop
player cookempressxoxo unsprint
player cookempressxoxo sneak
player cookempressxoxo look down
player cookempressxoxo use once