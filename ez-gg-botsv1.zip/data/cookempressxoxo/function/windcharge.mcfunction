execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player cookempressxoxo look at ^ ^ ^1

player cookempressxoxo hotbar 4
player cookempressxoxo use once
player cookempressxoxo jump once
