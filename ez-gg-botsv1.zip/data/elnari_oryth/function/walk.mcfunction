player elnari_oryth stop
player elnari_oryth move forward
player elnari_oryth unsprint
player elnari_oryth unsneak