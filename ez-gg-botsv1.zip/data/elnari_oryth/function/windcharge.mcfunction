execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player elnari_oryth look at ^ ^ ^1

player elnari_oryth hotbar 4
player elnari_oryth use once
player elnari_oryth jump once
