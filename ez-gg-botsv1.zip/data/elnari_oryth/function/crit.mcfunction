player elnari_oryth stop
player elnari_oryth jump once
execute if entity @s[scores={y_velocity=..-150,hit_cooldown=..9}] if entity @s[scores={y_velocity=-350..,hit_cooldown=..9}] run player elnari_oryth attack once
tag @s add playcriteffectperson
function players:playcriteffect
