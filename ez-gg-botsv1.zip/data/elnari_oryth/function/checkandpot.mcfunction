execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player elnari_oryth hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player elnari_oryth hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player elnari_oryth hotbar 9

#potting
player elnari_oryth stop
player elnari_oryth unsprint
player elnari_oryth sneak
player elnari_oryth look down
player elnari_oryth use once