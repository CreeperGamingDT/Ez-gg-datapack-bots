execute if entity @s[scores={hit_cooldown=..9}] run player elnari_oryth hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player elnari_oryth hotbar 2