execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player catdogwatuwant look at ^ ^ ^1

player catdogwatuwant hotbar 4
player catdogwatuwant use once
player catdogwatuwant jump once
