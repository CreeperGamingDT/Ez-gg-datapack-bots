player catdogwatuwant stop
player catdogwatuwant move forward
player catdogwatuwant unsprint
player catdogwatuwant unsneak