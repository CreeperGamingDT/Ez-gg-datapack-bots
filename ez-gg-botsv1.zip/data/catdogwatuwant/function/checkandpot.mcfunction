execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player catdogwatuwant hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player catdogwatuwant hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player catdogwatuwant hotbar 9

#potting
player catdogwatuwant stop
player catdogwatuwant unsprint
player catdogwatuwant sneak
player catdogwatuwant look down
player catdogwatuwant use once