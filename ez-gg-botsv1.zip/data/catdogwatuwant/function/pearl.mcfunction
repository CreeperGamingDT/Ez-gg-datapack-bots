summon armor_stand ~ ~ ~ {Tags:["random","random1"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random1"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

summon armor_stand ~ ~ ~ {Tags:["random","random2"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}


execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run execute as @p[tag=target] at @s run player catdogwatuwant look at ~ ~15 ~ 
# execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2]
execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run player catdogwatuwant hotbar 3 
# execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2]
execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run player catdogwatuwant use 

kill @e[tag=random]