player bigbrag_ez stop
player bigbrag_ez move forward
player bigbrag_ez unsprint
player bigbrag_ez unsneak