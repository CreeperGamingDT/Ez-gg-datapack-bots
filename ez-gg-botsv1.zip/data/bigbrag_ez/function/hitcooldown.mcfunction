execute if entity @s[scores={hit_cooldown=..9}] run player bigbrag_ez hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player bigbrag_ez hotbar 2