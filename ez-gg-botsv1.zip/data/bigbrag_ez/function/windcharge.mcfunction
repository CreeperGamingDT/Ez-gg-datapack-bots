execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player bigbrag_ez look at ^ ^ ^1

player bigbrag_ez hotbar 4
player bigbrag_ez use once
player bigbrag_ez jump once
