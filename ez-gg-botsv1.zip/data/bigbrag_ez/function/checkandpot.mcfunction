execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player bigbrag_ez hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player bigbrag_ez hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player bigbrag_ez hotbar 9

#potting
player bigbrag_ez stop
player bigbrag_ez unsprint
player bigbrag_ez sneak
player bigbrag_ez look down
player bigbrag_ez use once