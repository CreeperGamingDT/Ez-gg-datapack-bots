execute if entity @s[scores={hit_cooldown=..9}] run player dr1p__yak0 hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player dr1p__yak0 hotbar 2