execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player dr1p__yak0 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player dr1p__yak0 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player dr1p__yak0 hotbar 9

#potting
player dr1p__yak0 stop
player dr1p__yak0 unsprint
player dr1p__yak0 sneak
player dr1p__yak0 look down
player dr1p__yak0 use once