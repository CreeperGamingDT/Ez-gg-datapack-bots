player dr1p__yak0 stop
player dr1p__yak0 move forward
player dr1p__yak0 unsprint
player dr1p__yak0 unsneak