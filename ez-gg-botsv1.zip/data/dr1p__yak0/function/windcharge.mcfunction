execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player dr1p__yak0 look at ^ ^ ^1

player dr1p__yak0 hotbar 4
player dr1p__yak0 use once
player dr1p__yak0 jump once
