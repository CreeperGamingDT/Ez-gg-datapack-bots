execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player crunchempress66 hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player crunchempress66 hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player crunchempress66 hotbar 9

#potting
player crunchempress66 stop
player crunchempress66 unsprint
player crunchempress66 sneak
player crunchempress66 look down
player crunchempress66 use once