execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player crunchempress66 look at ^ ^ ^1

player crunchempress66 hotbar 4
player crunchempress66 use once
player crunchempress66 jump once
