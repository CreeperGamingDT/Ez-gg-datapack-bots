execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player bruedtaostr look at ^ ^ ^1

player bruedtaostr hotbar 4
player bruedtaostr use once
player bruedtaostr jump once
