player bruedtaostr stop
player bruedtaostr move forward
player bruedtaostr unsprint
player bruedtaostr unsneak