execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player bruedtaostr hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player bruedtaostr hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player bruedtaostr hotbar 9

#potting
player bruedtaostr stop
player bruedtaostr unsprint
player bruedtaostr sneak
player bruedtaostr look down
player bruedtaostr use once