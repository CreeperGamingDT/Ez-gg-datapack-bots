execute if entity @s[scores={hit_cooldown=..9}] run player cosmicwaffle hotbar 1
execute if entity @s[scores={hit_cooldown=..1}] run player cosmicwaffle hotbar 2