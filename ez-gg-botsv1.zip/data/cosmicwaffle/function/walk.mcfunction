player cosmicwaffle stop
player cosmicwaffle move forward
player cosmicwaffle unsprint
player cosmicwaffle unsneak