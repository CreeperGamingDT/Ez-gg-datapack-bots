execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player cosmicwaffle look at ^ ^ ^1

player cosmicwaffle hotbar 4
player cosmicwaffle use once
player cosmicwaffle jump once
