execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player cosmicwaffle hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player cosmicwaffle hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player cosmicwaffle hotbar 9

#potting
player cosmicwaffle stop
player cosmicwaffle unsprint
player cosmicwaffle sneak
player cosmicwaffle look down
player cosmicwaffle use once