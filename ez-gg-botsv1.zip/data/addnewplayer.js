const fs = require("fs");
const path = require("path")
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

(async()=>{
function ask(question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => resolve(answer));
  });
}

function checkIfValid(username) {
  if (typeof username !== "string" || username.length === 0) {
    return "Username cannot be empty.";
  }

  if (username.length > 16) {
    return "Username cannot be longer than 16 characters.";
  }
  if (username.length === 16) {
    return "i forgor if greater or equal to 16 length";
  }

  if (!/^[A-Za-z_]/.test(username)) {
    return "Username must start with a letter or underscore.";
  }

  if (!/^[A-Za-z0-9_]+$/.test(username)) {
    return "Username can only contain letters, numbers, and underscores.";
  }
  if (username !== username.toLowerCase()) return "Username cannot contain uppercases"

  return true; // valid
}

let newNameSplit;
for (let i = 0; i < 100; i++) {
newNameSplit = await ask("newName: ")
const isvalid = checkIfValid(newNameSplit)
if (isvalid === true) break;
break;
console.log(isvalid)
}
newNameSplit.split(",").forEach((newName)=>{
const copyPlayer = "xxdoubleueatsxx";

function duplicateFolder() {
  // Source and destination paths
  const source = `./${copyPlayer}`;
  const destination = `./${newName}`;

  // Copy recursively (true means include subfolders/files)
  fs.cpSync(source, destination, { recursive: true }, (err) => {
    if (err) {
      console.error("Error copying folder:", err);
    }
  });
  console.log("©️ Folder duplicated");
}

const find = new RegExp(copyPlayer, "g"); // text or regex to find
const replaceWith = newName; // what to replace it with

function replaceAllInFolder(folder) {
  const files = fs.readdirSync(folder);
  for (const file of files) {
    const filePath = path.join(folder, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      replaceAllInFolder(filePath); // recursive for subfolders
    } else {
      let content = fs.readFileSync(filePath, "utf8");
      const updated = content.replace(find, replaceWith);
      if (content !== updated) {
        fs.writeFileSync(filePath, updated, "utf8");
        console.log(`✅ Updated: ${filePath}`);
      }
    }
  }
}

function addPlayerToList(){
  const playerPath = "./players/function"
  const spawnPath = "spawn_mikearmy2.mcfunction"

  let aaloop = fs.readFileSync(path.join(playerPath,"aaloop_init.mcfunction"))
  let fixgap = fs.readFileSync(path.join(playerPath,"fixgap.mcfunction"))
  let setup = fs.readFileSync(path.join(playerPath,"setup.mcfunction"))
  let look = fs.readFileSync(path.join(playerPath,"look.mcfunction"))
  let spawn = fs.readFileSync(path.join(playerPath,spawnPath))
  let stop = fs.readFileSync(path.join(playerPath,"stop.mcfunction"))

  aaloop += `\nexecute as ${newName} at @s run function ${newName}:aaloop`
  fixgap += `\nexecute if data entity ${newName} {SelectedItem:{id:"minecraft:golden_apple"}} run player ${newName} use continuous`
  setup  += `\ntag ${newName} add team1`
  spawn += `\nplayer ${newName} spawn in adventure`
  stop   += `\nplayer ${newName} stop`
  look   += `\nplayer ${newName} look at ~ ~1 ~`

  fs.writeFileSync(path.join(playerPath,"aaloop_init.mcfunction"),aaloop)
  fs.writeFileSync(path.join(playerPath,"fixgap.mcfunction"),fixgap)
  fs.writeFileSync(path.join(playerPath,"setup.mcfunction"),setup)
  fs.writeFileSync(path.join(playerPath,spawnPath),spawn)
  fs.writeFileSync(path.join(playerPath,"stop.mcfunction"),stop)
  fs.writeFileSync(path.join(playerPath,"look.mcfunction"),look)

  console.log("➕ Added player to list")
}



duplicateFolder()
addPlayerToList()
replaceAllInFolder(`./${newName}/function`)
})
})().then(()=>rl.close())