player crispybehemoth stop
player crispybehemoth move forward
player crispybehemoth unsprint
player crispybehemoth unsneak