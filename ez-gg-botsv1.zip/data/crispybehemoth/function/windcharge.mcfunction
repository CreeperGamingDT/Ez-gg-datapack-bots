execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player crispybehemoth look at ^ ^ ^1

player crispybehemoth hotbar 4
player crispybehemoth use once
player crispybehemoth jump once
