execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player crispybehemoth hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player crispybehemoth hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player crispybehemoth hotbar 9

#potting
player crispybehemoth stop
player crispybehemoth unsprint
player crispybehemoth sneak
player crispybehemoth look down
player crispybehemoth use once