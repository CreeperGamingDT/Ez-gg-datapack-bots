execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player chesw_cker look at ^ ^ ^1

player chesw_cker hotbar 4
player chesw_cker use once
player chesw_cker jump once
