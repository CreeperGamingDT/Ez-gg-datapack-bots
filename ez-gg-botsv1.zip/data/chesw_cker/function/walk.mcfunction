player chesw_cker stop
player chesw_cker move forward
player chesw_cker unsprint
player chesw_cker unsneak