execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player chesw_cker hotbar 8
execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player chesw_cker hotbar 7
execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player chesw_cker hotbar 9

#potting
player chesw_cker stop
player chesw_cker unsprint
player chesw_cker sneak
player chesw_cker look down
player chesw_cker use once