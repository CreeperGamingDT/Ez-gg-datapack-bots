


#tanky (full netherite)
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s hotbar.0 with netherite_sword[minecraft:enchantments={sharpness:5,unbreaking:3,fire_aspect:2}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s hotbar.1 with netherite_axe[minecraft:enchantments={sharpness:5,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s hotbar.5 with golden_apple 64
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s hotbar.4 with water_bucket

execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s weapon.offhand with totem_of_undying



execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s armor.head with minecraft:netherite_helmet[minecraft:enchantments={protection:4,respiration:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:enchantments={protection:4}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:enchantments={protection:4}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tanky"]} run item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={protection:4}]


#tankyish (half netherite)
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyish"]} run item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:enchantments={protection:4}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyish"]} run item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={protection:4}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyish"]} run item replace entity @s hotbar.0 with netherite_sword[minecraft:enchantments={sharpness:5,fire_aspect:2}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyish"]} run item replace entity @s armor.legs with minecraft:diamond_leggings[minecraft:enchantments={protection:1},minecraft:damage=100]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyish"]} run item replace entity @s armor.head with minecraft:diamond_helmet[minecraft:enchantments={protection:1},minecraft:damage=100]


#tankyishy (half protection)
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyishy"]} run item replace entity @s armor.chest with minecraft:diamond_chestplate[minecraft:enchantments={protection:4},minecraft:damage=100]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["team1tankyishy"]} run item replace entity @s armor.feet with minecraft:diamond_boots[minecraft:enchantments={protection:4},minecraft:damage=100]





give @a[tag=team1,tag=!iron,tag=!mikearmyR1] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:long_strength"}] 5
give @a[tag=team1,tag=!iron,tag=!mikearmyR1] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:long_swiftness"}] 5
give @a[tag=team1,tag=!iron] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:long_fire_resistance"}] 5

#give @a[tag=team1,tag=cart_blastprot] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_strength"}] 5
give @a[tag=team1,tag=mikearmyR1] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_strength"}] 5
#give @a[tag=team1,tag=cart_blastprot] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_swiftness"}] 5
give @a[tag=team1,tag=mikearmyR1] minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_swiftness"}] 5



#iron
item replace entity @a[tag=iron] armor.chest with minecraft:iron_chestplate[minecraft:enchantments={protection:2}]
item replace entity @a[tag=iron] armor.feet with minecraft:iron_boots[minecraft:enchantments={protection:2}]
item replace entity @a[tag=iron] hotbar.0 with iron_sword[minecraft:enchantments={sharpness:3}]
item replace entity @a[tag=iron] armor.legs with minecraft:iron_leggings[minecraft:enchantments={protection:2}]
item replace entity @a[tag=iron] armor.head with minecraft:iron_helmet[minecraft:enchantments={protection:2}]
item replace entity @a[tag=iron] hotbar.5 with air
# golden_apple 2
#no water y windchange y perl y axe
item replace entity @a[tag=iron] hotbar.4 with air 
item replace entity @a[tag=iron] hotbar.3 with air 
item replace entity @a[tag=iron] hotbar.2 with air 
item replace entity @a[tag=iron,tag=!ironhighdamage] hotbar.1 with air 
#item replace entity @a[tag=iron] container.26 with minecraft:cobweb 2


#ironhighhealth
item replace entity @a[tag=ironhighhealth] armor.feet with minecraft:iron_boots[minecraft:enchantments={protection:2}]
item replace entity @a[tag=ironhighhealth] armor.chest with minecraft:diamond_chestplate[minecraft:enchantments={protection:4}]
item replace entity @a[tag=ironhighhealth] hotbar.5 with golden_apple 5
item replace entity @a[tag=ironhighhealth] container.26 with minecraft:cobweb 3

#ironhighdamage
item replace entity @a[tag=ironhighdamage] armor.feet with minecraft:diamond_boots[minecraft:enchantments={protection:2}]
item replace entity @a[tag=ironhighdamage] hotbar.0 with diamond_sword[minecraft:enchantments={sharpness:3}]
item replace entity @a[tag=ironhighdamage] hotbar.5 with golden_apple 5
item replace entity @a[tag=ironhighdamage] container.26 with minecraft:cobweb 5

#mikearmyR4
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR4"]} run item replace entity @s armor.head with minecraft:diamond_helmet[minecraft:enchantments={protection:2,unbreaking:1}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR4"]} run item replace entity @s armor.chest with minecraft:diamond_chestplate[minecraft:enchantments={protection:2,unbreaking:1}]
#,trim={material:"minecraft:diamond",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR4"]} run item replace entity @s armor.legs with minecraft:diamond_leggings[minecraft:enchantments={protection:2,unbreaking:1}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR4"]} run item replace entity @s armor.feet with minecraft:diamond_boots[minecraft:enchantments={protection:2,depth_strider:4,unbreaking:1}]

execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmy"]} run item replace entity @s weapon.offhand with shield[minecraft:enchantments={unbreaking:1}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmy"]} run item replace entity @s hotbar.0 with diamond_sword[minecraft:enchantments={sharpness:3,unbreaking:1}]

#mikearmyR3
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR3"]} run item replace entity @s armor.head with minecraft:diamond_helmet[minecraft:enchantments={protection:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR3"]} run item replace entity @s armor.chest with minecraft:diamond_chestplate[minecraft:enchantments={protection:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
#,trim={material:"minecraft:diamond",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR3"]} run item replace entity @s armor.legs with minecraft:diamond_leggings[minecraft:enchantments={protection:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR3"]} run item replace entity @s armor.feet with minecraft:diamond_boots[minecraft:enchantments={protection:4,depth_strider:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR3"]} run item replace entity @s hotbar.0 with diamond_sword[minecraft:enchantments={sharpness:5,unbreaking:3}]


#mikearmyR2
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR2"]} run item replace entity @s armor.head with minecraft:netherite_helmet[minecraft:enchantments={protection:4,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR2"]} run item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:enchantments={protection:4,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR2"]} run item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={protection:4,depth_strider:4,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR2"]} run item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:enchantments={protection:4,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR2"]} run item replace entity @s hotbar.0 with netherite_sword[minecraft:enchantments={sharpness:5,unbreaking:3,fire_aspect:2}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR2"]} run item replace entity @s weapon.offhand with totem_of_undying

#mikearmyR1
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s armor.head with minecraft:netherite_helmet[minecraft:enchantments={protection:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:enchantments={protection:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={protection:4,depth_strider:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:enchantments={protection:4,unbreaking:3},trim={material:"minecraft:redstone",pattern:"minecraft:flow"}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s hotbar.0 with netherite_sword[minecraft:enchantments={sharpness:5,unbreaking:3,fire_aspect:2}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s weapon.offhand with totem_of_undying
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["mikearmyR1"]} run item replace entity @s hotbar.5 with enchanted_golden_apple 64


#shield 
item replace entity @a[tag=team1shield] weapon.offhand with shield[minecraft:enchantments={unbreaking:3}]

#cart_blastprot
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s hotbar.0 with netherite_sword[minecraft:enchantments={sharpness:5,unbreaking:3,fire_aspect:2}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s hotbar.1 with netherite_axe[minecraft:enchantments={sharpness:5,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s hotbar.5 with golden_apple 64
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s hotbar.4 with water_bucket

execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s weapon.offhand with totem_of_undying

execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s armor.head with minecraft:netherite_helmet[minecraft:enchantments={protection:4,respiration:3,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:enchantments={protection:4,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:enchantments={blast_protection:4,unbreaking:3}]
execute if data storage ez-gg:playerstorage ctx.player.c{ranks:["cart_blastprot"]} run item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={protection:4,unbreaking:3}]
give @a[tag=cart_blastprot] tnt_minecart 10

#*iron
#*ironhighhealth
#*ironhighdamage

#*tanky
#*tankyish
#*tankyishy

#*mikearmy
#*mikearmyR4
#*mikearmyR3
#*mikearmyR2
#*mikearmyR1

#*cart_blastprot

#team1shield (not working)


#   hotbar
#   [sword] [axe] [pearl] [windcharge] [water] [gap] [strength] [speed] [fire_res/mace]



execute as @a[tag=team1] at @s run kill @e[type=item,distance=..3]
xp add @a[tag=team1] 3 levels

effect give @a[tag=team1] saturation 1 255 true
effect give @a[tag=team1] regeneration 1 255 true
function players:hotbar1
schedule function players:restockloop 1t replace