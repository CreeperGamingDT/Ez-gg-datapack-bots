$player $(username) hotbar 5
$player $(username) unsprint
function regular:weblook with storage ez-gg:playerstorage ctx.player
gamemode survival @s
$player $(username) use once

#scoreboard players set @s waterplacedelay 8

