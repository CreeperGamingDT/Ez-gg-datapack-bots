summon armor_stand ~ ~ ~ {Tags:["random","random1"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random1"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

summon armor_stand ~ ~ ~ {Tags:["random","random2"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}
summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}



$execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run summon armor_stand ~ ~1.5 ~ {Tags:["fakehit.$(username)"],NoGravity:1b,Invisible:1b}
$execute as @e[tag=fakehit.$(username)] at @s run attribute @s minecraft:scale base set 0.01
$execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run player $(username) attack once

data modify storage ez-gg:playerstorage ctx.playerschedule append from storage ez-gg:playerstorage ctx.player
schedule function regular:randomhitmiss.killarmorstand 1t append
# execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2]
# execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2]


kill @e[tag=random]