#$say $(username)
#$execute as $(username) at @s run say prerun
$execute as $(username) at @s if score @s aalooptimer matches ..0 run function regular:conditions with storage ez-gg:playerstorage ctx.player
#$execute as $(username) at @s run function regular:randomhitmiss with storage ez-gg:playerstorage ctx.player

#incase
$tag $(username) add team1