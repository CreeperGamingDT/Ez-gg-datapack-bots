#write timer in ticks
execute if entity @s[scores={team1indcount=0..1}] run scoreboard players set @s aalooptimer 2
execute if entity @s[scores={team1indcount=1..3}] run scoreboard players set @s aalooptimer 3
execute if entity @s[scores={team1indcount=3..7}] run scoreboard players set @s aalooptimer 4
execute if entity @s[scores={team1indcount=7..15}] run scoreboard players set @s aalooptimer 6
execute if entity @s[scores={team1indcount=15..20}] run scoreboard players set @s aalooptimer 10
execute if entity @s[scores={team1indcount=20..}] run scoreboard players set @s aalooptimer 15

execute if entity @p[tag=target,tag=overideaaloop2t] run scoreboard players set @s aalooptimer 2
execute if entity @p[tag=target,tag=overideaaloop3t] run scoreboard players set @s aalooptimer 3
execute if entity @p[tag=target,tag=overideaaloop4t] run scoreboard players set @s aalooptimer 4
execute if entity @p[tag=target,tag=overideaaloop5t] run scoreboard players set @s aalooptimer 5
execute if entity @p[tag=target,tag=overideaaloop6t] run scoreboard players set @s aalooptimer 6