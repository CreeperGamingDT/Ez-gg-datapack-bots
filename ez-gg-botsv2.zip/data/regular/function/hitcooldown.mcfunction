$execute if entity @s[scores={hit_cooldown=..9}] run player $(username) hotbar 1
#$execute if entity @s[scores={hit_cooldown=..1}] run player $(username) hotbar 2
execute if data storage ez-gg:playerstorage ctx.player.c{abilities:["mace"]} if entity @s[scores={y_velocity=..-500,mace_cooldown=..0}] run function regular:mace/maceequip with storage ez-gg:playerstorage ctx.player