$player $(username) stop
$player $(username) move forward
$player $(username) unsprint
$player $(username) unsneak