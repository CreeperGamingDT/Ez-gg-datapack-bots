tag @s remove raycast_stop
scoreboard players set @s ray_steps 0
execute anchored eyes positioned ^ ^ ^0.35 run function regular:raycast/step