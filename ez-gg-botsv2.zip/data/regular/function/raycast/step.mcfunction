#hit target
execute if entity @p[tag=raycast_target,distance=..0.9,limit=1] run tag @s add raycast_hit
#stop stepping
execute if entity @s[tag=raycast_hit] run tag @s add raycast_stop

#hit wall/block
execute unless block ~ ~ ~ #minecraft:replaceable run tag @s add raycast_stop

#track steps
scoreboard players add @s ray_steps 1

#stop if steps are too large
execute if score @s ray_steps matches 100.. run tag @s add raycast_stop

execute unless entity @s[tag=raycast_stop] positioned ^ ^ ^0.5 run function regular:raycast/step

#do on stop
execute if entity @s[tag=raycast_stop] run tag @p[tag=raycast_target] remove raycast_target
execute if entity @s[tag=raycast_stop] run tag @s remove raycast_stop