$execute unless entity @s[nbt={active_effects:[{id:"minecraft:speed"}]}] run player $(username) hotbar 8
$execute unless entity @s[nbt={active_effects:[{id:"minecraft:strength"}]}] run player $(username) hotbar 7
$execute unless entity @s[nbt={active_effects:[{id:"minecraft:fire_resistance"}]}] run player $(username) hotbar 9

#potting
$player $(username) stop
$player $(username) unsprint
$player $(username) sneak
$player $(username) look down
$player $(username) use once