summon armor_stand ~ ~ ~ {Tags:["random","random1"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

summon armor_stand ~ ~ ~ {Tags:["random","random2"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

summon armor_stand ~ ~ ~ {Tags:["random","random3"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

#if random selected entity is random2
$execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2] run tag $(username) add pearl_try


#switch to slot
$execute if entity @s[tag=pearl_try] run player $(username) hotbar 3 


#checking if above/nah
execute store result score pos3 playerposY run data get entity @p[tag=target] Pos[1] 1000
execute store result score pos2 playerposY run data get entity @s Pos[1] 1000

scoreboard players operation diff playerposY = pos3 playerposY
scoreboard players operation diff playerposY -= pos2 playerposY

execute if score diff playerposY matches -1300.. run tag @e[tag=random2] add above

#raycast to see if can see target
tag @p[tag=target] add raycast_target
execute if entity @s[tag=pearl_try] run function regular:raycast/start


#if player is above
$execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target] at @s run player $(username) look at ~ ~15 ~ 
execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target] at @s run say 15
$execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target,distance=..40] at @s run player $(username) look at ~ ~10 ~ 
execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target,distance=..40] at @s run say 10
$execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target,distance=..30] at @s run player $(username) look at ~ ~5 ~ 
execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target,distance=..30] at @s run say 5
$execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target,distance=..20] at @s run player $(username) look at ~ ~ ~ 
execute if entity @s[tag=pearl_try,tag=above] run execute as @p[tag=target,distance=..20] at @s run say 0

#if player is below
$execute if entity @s[tag=pearl_try,tag=!above,tag=raycast_hit] run execute as @p[tag=target,distance=..25] at @s run player $(username) look at ~ ~ ~ 
execute if entity @s[tag=pearl_try,tag=!above,tag=raycast_hit] run execute as @p[tag=target,distance=..25] at @s run say belowray
execute if entity @s[tag=pearl_try,tag=!above,tag=!raycast_hit] run execute as @p[tag=target,distance=..25] at @s run say belowraynah
# execute as @e[tag=random,limit=1,sort=random] if entity @s[tag=random2]


#if isnt trying, dont look sus (by looking normal)
$execute if entity @s[tag=!pearl_try] run execute as @p[tag=target] at @s run player $(username) look at ~ ~1.1 ~ 

#use pearl
$execute if entity @s[tag=pearl_try] run player $(username) use once

execute if entity @s[tag=pearl_try] run say pearl

kill @e[tag=random]
tag @s remove pearl_try
tag @s remove raycast_hit