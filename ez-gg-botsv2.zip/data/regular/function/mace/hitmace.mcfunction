playsound minecraft:item.mace.hit player @a ~ ~ ~ 1 1
playsound minecraft:item.mace.smash_ground player @a ~ ~ ~ 1 1
playsound minecraft:item.mace.charge player @a ~ ~ ~ 1 1

particle block{block_state:{Name:obsidian}} ~ ~ ~ 1.5 2 1.5 1 80
particle minecraft:dust_plume ~ ~ ~ 0.5 1.5 0.5 0.2 60
particle minecraft:crit ~ ~ ~ 0.5 1.5 0.5 0.2 60

$execute as $(username) at @s run tp @s ~ ~ ~

$damage @p[tag=target] 62 minecraft:mace_smash by $(username)
$scoreboard players set $(username) mace_cooldown 200
#2400
$player $(username) hotbar 1