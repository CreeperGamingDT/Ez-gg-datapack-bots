$player $(username) hotbar 9
item replace entity @s hotbar.8 with mace[minecraft:enchantments={unbreaking:3,density:5}]