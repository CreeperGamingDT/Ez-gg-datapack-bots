tag @p[distance=0.001..,tag=!team1attack,tag=team1follow] add follow



execute if entity @s[tag=team1R] run tag @p[distance=0.001..,tag=!team1attack,tag=team1follow,tag=!team1R,tag=!team1] add target
execute if entity @s[tag=team1R] unless entity @p[distance=0.001..,tag=team1attack] run tag @p[distance=0.001..,gamemode=survival,tag=!team1notattack,tag=!follow,tag=!team1R,tag=!team1] add target
execute if entity @s[tag=team1R] run tag @p[distance=0.001..,gamemode=survival,tag=team1attack,tag=!follow,tag=!team1R,tag=!team1] add target
execute unless entity @s[tag=team1R] run tag @p[distance=0.001..,tag=!team1attack,tag=team1follow,tag=!team1] add target
execute unless entity @s[tag=team1R] unless entity @p[distance=0.001..,tag=team1attack] run tag @p[distance=0.001..,gamemode=survival,tag=!team1notattack,tag=!follow,tag=!team1] add target
execute unless entity @s[tag=team1R] run tag @p[distance=0.001..,gamemode=survival,tag=team1attack,tag=!follow,tag=!team1] add target

#reset aaloop timer
function regular:aaloop.timerset with storage ez-gg:playerstorage ctx.player


#$execute as @p[distance=0.001..,gamemode=!survival,tag=!target] at @s if entity @s[tag=!target] run player $(username) stop


#$say $(username) $(hit_distance) $(pearl_distance) we


$execute if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={health=..$(gap_health)}] add gap
$execute if items entity @s hotbar.5 minecraft:enchanted_golden_apple run tag @s[scores={health=..$(gap_health)}] add gap
#*sat gap
#execute if items entity @s hotbar.5 minecraft:golden_apple run tag @s[scores={sat=..19}] add gap

#haswater
execute if items entity @s hotbar.4 minecraft:water_bucket run tag @s[tag=!gap] add haswater
execute if items entity @s hotbar.4 minecraft:bucket run tag @s[tag=!gap] add haswater

#cobweb
execute if block ~0.3 ~ ~0.3 cobweb run tag @s[tag=!gap] add inwebPP
execute if block ~-0.3 ~ ~0.3 cobweb run tag @s[tag=!gap] add inwebNP
execute if block ~-0.3 ~ ~-0.3 cobweb run tag @s[tag=!gap] add inwebNN
execute if block ~0.3 ~ ~-0.3 cobweb run tag @s[tag=!gap] add inwebPN

tag @s[tag=inwebPP] add inweb
tag @s[tag=inwebNP] add inweb
tag @s[tag=inwebNN] add inweb
tag @s[tag=inwebPN] add inweb

execute if block ~ ~ ~ cobweb run tag @s[tag=!gap,scores={waterplacedelay=..1}] add inwebfull


#$execute if data entity @s {Inventory:[{Slot:4b,id:"minecraft:bucket"}]} run execute as @e[tag=retrivewater_$(username)] at @s run player $(username) look down

#*THE MACE
execute if data storage ez-gg:playerstorage ctx.player.c{abilities:["mace"]} if data entity @p[tag=target,distance=..2.9,limit=1,tag=!disablemacers] {} if block ~ ~-1 ~ air if entity @s[scores={y_velocity=..-500}] if data entity @s {SelectedItem:{id:"minecraft:mace"}} run tag @s[tag=!gap,tag=!inweb] add hitmace
execute if data storage ez-gg:playerstorage ctx.player.c{abilities:["mace"]} if data entity @p[tag=target,distance=..6,limit=1,tag=!disablemacers] {} unless block ~ ~-1 ~ air if entity @s[scores={y_velocity=-100..,mace_cooldown=..0}] run tag @s[tag=!gap,tag=!inweb,tag=!hitmace] add upmace
execute if data storage ez-gg:playerstorage ctx.player.c{abilities:["mace"]} if data entity @p[tag=target,limit=1] {SelectedItem:{id:"minecraft:golden_apple"}} if entity @s[scores={mace_cooldown=20..}] if data entity @p[tag=target,distance=..2.9,limit=1,tag=!disablemacers] {} if block ~ ~-1 ~ air if entity @s[scores={y_velocity=..-500}] if data entity @s {SelectedItem:{id:"minecraft:mace"}} run tag @s[tag=!gap,tag=!inweb] add hitmace
#execute if data storage ez-gg:playerstorage ctx.player.c{abilities:["mace"]} run say hi

#normal
execute if entity @p[tag=target,distance=..2,tag=!follow] run tag @s[tag=!gap,tag=!inweb] add crit
#execute if entity @p[tag=target,distance=..2,tag=!follow] run tag @s[tag=!gap,tag=!inweb] add backward
$execute if entity @p[tag=target,distance=2..] unless entity @p[tag=follow,distance=..6] unless entity @e[tag=weblook.$(username)] run tag @s[tag=!crit,tag=!gap] add walk
execute if entity @p[tag=target,distance=4..,tag=!nosprintjumptoward] unless entity @p[tag=follow,distance=..10] run tag @s[tag=!crit,tag=!gap,tag=!inweb] add sprintjump

#abovenowalk
function players:sssabovenowalk

#water
execute if entity @p[tag=target] if block ~ ~-0.3 ~ water unless block ~ ~1.5 ~ water unless block ~ ~2 ~ water if entity @p[tag=target,dy=-50] run tag @s[tag=!gap] add watersneak
execute if entity @p[tag=target] if block ~ ~-0.3 ~ water unless entity @p[tag=target,dy=-50] run tag @s[tag=!gap,tag=!watersneak] add waterjump
execute if entity @p[tag=target] if block ~ ~-0.3 ~ water if block ~ ~-1 ~ water run tag @s[tag=!gap] add inwater

#skill
execute if entity @p[tag=target,distance=..3,tag=!follow] run tag @s[tag=!gap,tag=!sprintjump,tag=!inweb] add strafe
execute if entity @p[tag=target] run tag @s[tag=!gap,tag=!inweb] add hitcooldown

#skill issue
#hitmiss
#$execute if entity @p[tag=target,distance=..3.4,tag=!follow] if entity @p[tag=target,distance=$(hit_distance)..] if entity @s[scores={hit_cooldown=..9}] run tag @s[tag=!crit,tag=!gap] add combohit

#regular hit
$execute if entity @p[tag=target,distance=..$(hit_distance),tag=!follow] if entity @p[tag=target,distance=2.13..] if entity @s[scores={hit_cooldown=..9}] run tag @s[tag=!crit,tag=!gap] add combohit
$execute if entity @p[tag=target,distance=..$(hit_distance),tag=!follow] if entity @s[scores={hit_cooldown=..9}] run tag @s[tag=!crit,tag=!gap,tag=inweb] add combohit

#pot
execute if entity @p[tag=target,tag=!follow] unless entity @s[nbt={active_effects:[{id:"minecraft:speed"},{id:"minecraft:strength"},{id:"minecraft:fire_resistance"}]}] if items entity @s hotbar.* minecraft:splash_potion run tag @s[tag=!gap,tag=!crit,tag=!inwater,tag=!inweb] add pot

#pearl
$execute if entity @p[tag=target,distance=$(pearl_distance)..,tag=!follow] if items entity @s hotbar.2 minecraft:ender_pearl unless entity @p[tag=target,nbt={Inventory:[{Slot:102b,id:"minecraft:elytra"}]}] run tag @s[tag=!crit,tag=!gap,tag=!inwater,tag=!pot] add pearl

#look
$execute if entity @p[tag=target] if entity @s[tag=!pot,tag=!pearl,tag=!cart] as @p[tag=target] at @s unless entity @e[tag=weblook.$(username)] run player $(username) look at ~ ~1.1 ~
$execute if entity @p[tag=follow,distance=..6] if entity @s[tag=!pot,tag=!inweb,tag=!pearl,tag=!gap] run player $(username) stop


#cart
execute if data storage ez-gg:playerstorage ctx.player.c{abilities:["cart"]} run function regular:cart/cartcheck with storage ez-gg:playerstorage ctx.player

$execute if entity @s[tag=backward,tag=!cart] run player $(username) unsprint
$execute if entity @s[tag=backward,tag=!cart] run player $(username) move backward
#execute if entity @s[tag=walk,tag=!cart] run function regular:walk with storage ez-gg:playerstorage ctx.player
$execute if entity @s[tag=nearest_left,tag=!cart] run player $(username) move right
$execute if entity @s[tag=nearest_right,tag=!cart] run player $(username) move left
$execute if entity @s[tag=backward,tag=!cart] run player $(username) unsprint
$execute if entity @s[tag=backward,tag=!cart] run player $(username) move backward
execute if entity @s[tag=hitcooldown,tag=!cart] run function regular:hitcooldown with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=pearl,tag=!cart] run function regular:pearl with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=walk,tag=!cart] run function regular:jumpoverblock with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=crit,tag=!cart] run function regular:crit with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=gap] run function regular:gap with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=!gap] run attribute @s minecraft:movement_speed modifier remove gap_slowdown
$execute if entity @s[tag=sprintjump,tag=!cart] run player $(username) jump
$execute if entity @s[tag=sprintjump,tag=!cart] run player $(username) sprint
#should stop instant let go and press sprint hitting
$execute if entity @s[tag=sprintjump,tag=!cart] if score @s hit_cooldown matches 15.. run player $(username) unsprint
$execute if entity @s[tag=waterjump,tag=!cart] run player $(username) jump continuous
$execute if entity @s[tag=waterjump,tag=!cart] run player $(username) unsneak
$execute if entity @s[tag=watersneak,tag=!cart] run player $(username) sneak
$execute if entity @s[tag=combohit,tag=!cart] run player $(username) attack once
execute if entity @s[tag=combohit,tag=!cart] run scoreboard players set @s hit 1
#execute if entity @s[tag=strafe] run function regular:strafe with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=pot,tag=!cart] run function regular:checkandpot with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=inweb,tag=!cart,tag=!webout] run scoreboard players set @s waterplacedelay 20
execute if entity @s[tag=inweb,tag=!cart] run function regular:webout with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=upmace,tag=!cart] run function regular:windcharge with storage ez-gg:playerstorage ctx.player
#execute if entity @s[tag=gapscared] run function regular:windcharge with storage ez-gg:playerstorage ctx.player
execute if entity @s[tag=hitmace,tag=!cart] as @p[tag=target] at @s run function regular:mace/hitmace with storage ez-gg:playerstorage ctx.player

#cobweb outing sortof
$execute as @s if data entity @s {Inventory:[{Slot:4b,id:"minecraft:bucket"}]} at @s if entity @e[tag=weblook.$(username)] run function regular:webout2 with storage ez-gg:playerstorage ctx.player
#social distancing
function players:checknearestside


tag @p[tag=target] remove target
tag @p[tag=follow] remove follow