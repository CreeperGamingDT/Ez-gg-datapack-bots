$execute as @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] at @s align xyz run player $(username) look at ~0.5 ~1.3 ~0.5

$execute as @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] at @s unless block ~ ~ ~ cobweb run tag $(username) add continue


$execute if entity @s[tag=continue] run player $(username) stop
$player $(username) hotbar 5
$execute if entity @s[tag=continue] run player $(username) unsprint
$execute if entity @s[tag=continue] run player $(username) use once

scoreboard players set @s waterplacedelay 15

$execute if entity @s[tag=continue] run kill @e[tag=weblook.$(username)]
tag @s[tag=continue] remove continue
tag @s remove webout