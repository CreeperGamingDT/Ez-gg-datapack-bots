#spawn one look target
$execute unless entity @e[type=armor_stand,tag=weblook.$(username)] at @s run summon armor_stand ~ ~ ~ {Tags:["weblook.$(username)"],NoGravity:1b,Invisible:1b,Marker:1b,Invulnerable:1b}


#corners
$execute if entity @s[tag=inwebPP] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~0.3 ~ ~0.3

$execute if entity @s[tag=inwebNP] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~-0.3 ~ ~0.3

$execute if entity @s[tag=inwebNN] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~-0.3 ~ ~-0.3

$execute if entity @s[tag=inwebPN] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~0.3 ~ ~-0.3


#straights
$execute if entity @s[tag=inwebNP,tag=inwebPP] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~ ~ ~0.3

$execute if entity @s[tag=inwebNP,tag=inwebNN] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~-0.3 ~ ~

$execute if entity @s[tag=inwebNP,tag=inwebPN] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~-0.3 ~ ~

$execute if entity @s[tag=inwebPP,tag=inwebNN] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~-0.3 ~ ~


#down
$execute if entity @s[tag=inwebPP,tag=inwebNP,tag=inwebNN,tag=inwebPN] at @s run tp @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] ~ ~ ~


#look
$execute as @e[type=armor_stand,tag=weblook.$(username),sort=nearest,limit=1] at @s align xz run player $(username) look at ~0.5 ~ ~0.5
