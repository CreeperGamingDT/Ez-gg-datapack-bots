function regular:_randomhitmiss.killarmorstand with storage ez-gg:playerstorage ctx.playerschedule[0]
data remove storage ez-gg:playerstorage ctx.playerschedule[0]