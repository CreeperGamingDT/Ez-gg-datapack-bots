$player $(username) look down
$execute as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s run player $(username) look at ^ ^ ^1

$player $(username) hotbar 4
$execute unless block ~ ~-0.2 ~ #replaceable run player $(username) use once
$player $(username) jump once
