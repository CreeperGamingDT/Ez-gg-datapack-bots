$execute as $(username) at @s as @e[type=tnt_minecart,distance=0.5..3.5,limit=1,sort=nearest] at @s run player $(username) hotbar 1
$execute as $(username) at @s as @e[type=tnt_minecart,distance=0.5..3.5,limit=1,sort=nearest] at @s run player $(username) attack once

schedule function regular:cart/breakcart/tagremove 1t replace