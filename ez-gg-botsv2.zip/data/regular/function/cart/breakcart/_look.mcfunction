$execute as $(username) at @s as @e[type=tnt_minecart,distance=0.5..3.5,limit=1,sort=nearest] at @s run player $(username) look at ~ ~ ~
schedule function regular:cart/breakcart/break 4t
schedule function regular:cart/breakcart/tagremove 5t replace