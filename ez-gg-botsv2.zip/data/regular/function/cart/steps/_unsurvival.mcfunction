$tag $(username) remove team1notattack
$gamemode adventure $(username)
tag @e[tag=mec] remove down1_cart
tag @e[tag=mec] remove up1_cart
tag @e[tag=mec] remove regular_cart
tag @e[tag=mec] remove cart
tag @e[tag=mec] remove mec
tag @e[tag=cartarrow] remove cartarrow