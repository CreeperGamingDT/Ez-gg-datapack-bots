$execute as $(username) at @s run summon armor_stand ~ ~ ~ {Tags:["yawonly"],NoGravity:1b}

# Copy yaw from nearest player to armor stand
$execute store result entity @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] Rotation[0] float 1 run data get entity $(username) Rotation[0]

execute as @e[tag=yawonly,limit=1] at @s run tp @s ^ ^ ^3
$execute if entity @e[tag=mec,limit=1,tag=regular_cart] as @e[tag=yawonly,limit=1] at @s run player $(username) look at ~ ~ ~
$execute if entity @e[tag=mec,limit=1,tag=down1_cart] as @e[tag=yawonly,limit=1] at @s run player $(username) look at ~ ~-1.5 ~
$execute if entity @e[tag=mec,limit=1,tag=up1_cart] as @e[tag=yawonly,limit=1] at @s run player $(username) look at ~ ~1.12 ~
kill @e[tag=yawonly]