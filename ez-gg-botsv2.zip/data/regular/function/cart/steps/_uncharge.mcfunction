$player $(username) use once
schedule function regular:cart/steps/tagarrow 1t