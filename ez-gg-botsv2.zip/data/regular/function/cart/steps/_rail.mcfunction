$item replace entity $(username) hotbar.8 with rail 64
$player $(username) hotbar 9
$player $(username) use once