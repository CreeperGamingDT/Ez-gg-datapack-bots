$tag $(username) add mec

$execute as $(username) at @s run summon armor_stand ~ ~ ~ {Tags:["yawonly"],NoGravity:1b}

# Copy yaw from nearest player to armor stand
$execute store result entity @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] Rotation[0] float 1 run data get entity $(username) Rotation[0]

execute as @e[tag=yawonly,limit=1] at @s run tp @s ^ ^ ^3

execute as @e[tag=yawonly,limit=1] at @s if block ~ ~-1 ~ #replaceable if block ^ ^-1 ^-0.8 #replaceable unless block ~ ~-1.5 ~ #replaceable run tag @a[tag=mec,limit=1] add down1_cart
execute as @e[tag=yawonly,limit=1] at @s unless block ~ ~-0.5 ~ #replaceable unless block ~ ~ ~ #replaceable if block ~ ~1.5 ~ #replaceable run tag @a[tag=mec,limit=1] add up1_cart
execute as @e[tag=yawonly,limit=1] at @s unless block ~ ~-1 ~ #replaceable if block ~ ~ ~ #replaceable run tag @a[tag=mec,limit=1] add regular_cart

$execute if entity @e[tag=mec,limit=1,tag=regular_cart] as @e[tag=yawonly,limit=1] at @s run player $(username) look at ~ ~2.2 ~
$execute if entity @e[tag=mec,limit=1,tag=down1_cart] as @e[tag=yawonly,limit=1] at @s run player $(username) look at ~ ~0.8 ~
$execute if entity @e[tag=mec,limit=1,tag=up1_cart] as @e[tag=yawonly,limit=1] at @s run player $(username) look at ~ ~2.4 ~

kill @e[tag=yawonly]