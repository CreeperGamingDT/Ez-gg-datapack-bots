$item replace entity $(username) container.24 with arrow
$item replace entity $(username) hotbar.8 with bow[minecraft:enchantments={unbreaking:3,power:5,flame:1}]
$player $(username) hotbar 9
$player $(username) use continuous

schedule function regular:cart/steps/uncharge 4t replace