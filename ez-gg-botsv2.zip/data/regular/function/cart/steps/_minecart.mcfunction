$item replace entity $(username) hotbar.8 with tnt_minecart
$player $(username) hotbar 9
$player $(username) use once


schedule function regular:cart/steps/unsurvival 1t
