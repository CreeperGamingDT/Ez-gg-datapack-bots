scoreboard objectives add playerposY dummy

execute store result score pos3 playerposY run data get entity @p[tag=target] Pos[1] 1000
execute store result score pos2 playerposY run data get entity @s Pos[1] 1000

scoreboard players operation diff playerposY = pos3 playerposY
scoreboard players operation diff playerposY -= pos2 playerposY

execute if score diff playerposY matches 1300.. run tag @s add above
execute if score diff playerposY matches ..-1500 run tag @s add above


execute if entity @p[tag=target,distance=3.5..4.5,limit=1,tag=!disablecarters] unless block ~ ~-1 ~ air if entity @s[scores={cart_cooldown=..0,y_velocity=-79,health=15..},tag=!gap,tag=!inweb,tag=!pot,tag=!above] run tag @s add cart
execute if entity @e[type=tnt_minecart,distance=0.5..3.5,limit=1] if entity @s[tag=!gap,tag=!inweb,tag=!pot] run tag @s add breakcart
execute if entity @s[tag=breakcart,tag=!inprogress_breakcart] run schedule function regular:cart/breakcart/look 5t
execute if entity @s[tag=breakcart] run tag @s add cart
execute if entity @s[tag=cart,tag=!breakcart,scores={cart_cooldown=..0,health=10..}] run function regular:cart/cart with storage ez-gg:playerstorage ctx.player

execute if entity @s[tag=breakcart] run tag @s add inprogress_breakcart

kill @e[tag=temp]
tag @p[tag=tempP] remove tempP
tag @s remove above