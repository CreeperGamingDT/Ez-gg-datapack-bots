$tag $(username) add team1notattack
$player $(username) stop
$gamemode survival $(username)
say uwuw

function regular:cart/steps/_lookcharge with storage ez-gg:playerstorage ctx.player
schedule function regular:cart/steps/charge 1t
schedule function regular:cart/steps/lookrail 7t
schedule function regular:cart/steps/rail 10t
schedule function regular:cart/steps/minecart 11t

$scoreboard players set $(username) cart_cooldown $(cart_cooldown)