execute if entity @s[scores={hit=1..}] run scoreboard players set @s hit_cooldown 20
execute if entity @s[scores={hit_cooldown=3..}] run scoreboard players operation @s hit_cooldown -= one one
execute if entity @s[scores={mace_cooldown=0..}] run scoreboard players operation @s mace_cooldown -= one one
execute if entity @s[scores={hit=0..}] run scoreboard players set @s hit 0