data remove storage ez-gg:playerstorage players
tag @a[tag=team1] remove team1tanky
tag @a[tag=team1] remove team1tankyish
tag @a[tag=team1] remove team1tankyishy
tag @a[tag=team1] remove iron
tag @a[tag=team1] remove ironhighdamage
tag @a[tag=team1] remove ironhighhealth

tag @a[tag=team1] remove mikearmy
tag @a[tag=team1] remove mikearmyR4
tag @a[tag=team1] remove mikearmyR3
tag @a[tag=team1] remove mikearmyR2
tag @a[tag=team1] remove mikearmyR1

#setting up for loop

#i
