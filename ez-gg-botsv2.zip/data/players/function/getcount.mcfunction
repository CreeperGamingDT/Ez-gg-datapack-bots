scoreboard objectives add team1count dummy
scoreboard players set #count team1count 0
execute as @a[tag=team1] run scoreboard players add #count team1count 1
tellraw @s [{"text":"Bot Player Count: ","color":"gold"},{"score":{"name":"#count","objective":"team1count"},"color":"white"}]
