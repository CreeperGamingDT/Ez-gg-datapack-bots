tp @a[tag=team1] @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 10 35 false @s