function players:setup
function players:restock
function players:aaloop_init
function players:stop
execute as @a[tag=idle] run team leave @s
tag @e[tag=idle] remove idle
tag @e[tag=cart] remove cart
tag @e[tag=runHeIS] remove runHeIS
tag @e[tag=waitHeAbove] remove waitHeAbove
tag @e[tag=breakcart] remove breakcart
tag @e[tag=inprogress_breakcart] remove inprogress_breakcart
kill @e[tag=zp_tmp]