#each

#set the data to send
data modify storage ez-gg:playerstorage ctx.player set from storage ez-gg:playerstorage temp.players[0]
#send it
$function $(run) with storage ez-gg:playerstorage ctx.player

#remove first element
data remove storage ez-gg:playerstorage temp.players[0]

#run again
execute if data storage ez-gg:playerstorage temp.players[0] run function players:iteration with storage ez-gg:playerstorage ctx.forloop