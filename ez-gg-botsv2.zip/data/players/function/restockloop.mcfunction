execute as @a[tag=team1] at @s run function players:sssrestockloop_internal

schedule function players:restockloop 1s replace