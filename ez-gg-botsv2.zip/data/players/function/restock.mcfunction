clear @a[tag=team1]
xp set @a[tag=team1] 0 levels

item replace entity @a[tag=team1] hotbar.0 with diamond_sword[minecraft:enchantments={sharpness:3,unbreaking:3,fire_aspect:2}]
item replace entity @a[tag=team1] hotbar.1 with diamond_axe[minecraft:enchantments={sharpness:3,unbreaking:3}]
item replace entity @a[tag=team1] hotbar.5 with golden_apple 64
item replace entity @a[tag=team1] hotbar.4 with water_bucket


item replace entity @a[tag=team1] armor.head with minecraft:diamond_helmet[minecraft:enchantments={protection:1,respiration:1},minecraft:damage=100]
item replace entity @a[tag=team1] armor.chest with minecraft:diamond_chestplate[minecraft:enchantments={protection:1},minecraft:damage=100]
item replace entity @a[tag=team1] armor.legs with minecraft:diamond_leggings[minecraft:enchantments={protection:1},minecraft:damage=100]
item replace entity @a[tag=team1] armor.feet with minecraft:diamond_boots[minecraft:enchantments={protection:1,depth_strider:4},minecraft:damage=100]

#item replace entity @a[tag=team1] container.26 with minecraft:experience_bottle[minecraft:enchantments={}] 64
#item replace entity @a[tag=team1] container.25 with minecraft:experience_bottle[minecraft:enchantments={}] 64

#setup forloop (I DONT WANNA TYPE THIS ANYMORE I'M DONE)
scoreboard players set i idx 0
#len
execute store result score len idx run data get storage ez-gg:playerstorage players
#temp array
data modify storage ez-gg:playerstorage temp.players set from storage ez-gg:playerstorage players

#set output
data modify storage ez-gg:playerstorage ctx.forloop.run set value "regular:restock"

function players:iteration with storage ez-gg:playerstorage ctx.forloop