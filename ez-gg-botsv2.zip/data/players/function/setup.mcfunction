scoreboard objectives add hit minecraft.custom:minecraft.damage_dealt
scoreboard objectives add hit_cooldown dummy
scoreboard objectives add mace_cooldown dummy
scoreboard objectives add cart_cooldown dummy

scoreboard objectives add y_velocity dummy

scoreboard players set @a hit 0
scoreboard players set @a hit_cooldown 0

scoreboard players set @a mace_cooldown 0
scoreboard players set @a cart_cooldown 0


scoreboard objectives add health health {"text":"❤","color":"red"}
scoreboard objectives add sat food

scoreboard objectives add waterplacedelay dummy
scoreboard players set @a waterplacedelay 0

scoreboard objectives add one dummy
scoreboard players set one one 1

scoreboard objectives add team1count dummy
scoreboard objectives add team1indcount dummy
scoreboard players set count count 0

scoreboard objectives add idx dummy
scoreboard players set i idx 0

scoreboard objectives add aalooptimer dummy
scoreboard players set @a[tag=team1] aalooptimer 0

scoreboard objectives add pearl_ray_steps dummy
scoreboard objectives add playerposY dummy


function players:aaloop
function players:aaloop.timer
function players:restockloop