tp @a[tag=team1] @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 1 1 false @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 1 1 false @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 1 1 false @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 1 1 false @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 1 1 false @s
execute as @a[tag=team1] at @s run spreadplayers ~ ~ 1 1 false @s