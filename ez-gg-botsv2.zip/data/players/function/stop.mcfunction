#setting up for loop

#i
scoreboard players set i idx 0
#len
execute store result score len idx run data get storage ez-gg:playerstorage players
#temp array
data modify storage ez-gg:playerstorage temp.players set from storage ez-gg:playerstorage players

#set output
data modify storage ez-gg:playerstorage ctx.forloop.run set value "regular:stop"

function players:iteration with storage ez-gg:playerstorage ctx.forloop