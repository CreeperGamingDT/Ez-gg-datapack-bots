execute as @a[scores={aalooptimer=0..},tag=team1] at @s run scoreboard players operation @s aalooptimer -= one one


#loop
schedule function players:aaloop.timer 1t replace