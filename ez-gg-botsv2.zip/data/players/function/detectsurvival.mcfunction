tag @a[tag=!team1,gamemode=survival] add survival
execute as @a[tag=!team1,gamemode=!survival,tag=survival] run function players:stop
execute as @a[tag=!team1,gamemode=!survival,tag=survival] run schedule function players:stop 10t replace
tag @a[tag=!team1,gamemode=!survival] remove survival
