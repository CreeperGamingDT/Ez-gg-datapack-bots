tag @s remove nearest_left
tag @s remove nearest_right
tag @s remove nearest_both

execute if entity @p[tag=target,tag=!nosocialdistancing] positioned ^2 ^ ^ if entity @p[distance=..1.99,tag=team1] run tag @s[tag=!gap,tag=!crit,tag=!inweb,tag=!pot,tag=walk] add nearest_left
execute if entity @p[tag=target,tag=!nosocialdistancing] positioned ^-2 ^ ^ if entity @p[distance=..1.99,tag=team1] run tag @s[tag=!gap,tag=!crit,tag=!inweb,tag=!pot,tag=walk] add nearest_right

#execute if entity @s[tag=nearest_left] run say le
#execute if entity @s[tag=nearest_right] run say righ

execute if entity @s[tag=nearest_left,tag=nearest_right] run tag @s add nearest_both

execute if entity @s[tag=nearest_both] run tag @s remove nearest_left
execute if entity @s[tag=nearest_both] run tag @s remove nearest_right