effect give @s resistance infinite 2 true
effect give @s fire_resistance infinite 0 true
effect give @s regeneration infinite 200 true
effect give @s health_boost infinite 20 true
effect give @s saturation infinite 200 true