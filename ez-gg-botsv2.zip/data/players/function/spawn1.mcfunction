#schedule function players:onspawn 10t replace

player ramsondecease spawn in adventure
player xXdoubleueatsXx spawn in adventure
player _atlasbehemoth22 spawn in adventure
player putinfarten_2 spawn in adventure
player wingsburden12 spawn in adventure
player x22telescale_ spawn in adventure
player _poloshirtxoxo spawn in adventure
player silksecond2021 spawn in adventure
player bigbrag_ez spawn in adventure
player cateatfinger64 spawn in adventure
player toastypickleiii spawn in adventure
player woblechickstick4 spawn in adventure
player _vennressuract spawn in adventure
player zynqrynx_ spawn in adventure
player apexchicken5681 spawn in adventure
player dontv9i0 spawn in adventure
player nachix010 spawn in adventure
player mega67skibidi spawn in adventure
player imaginlosin_aur1 spawn in adventure

player _flagflamesfan91 spawn in adventure
player _8ggw3_mball spawn in adventure
player chesw_cker spawn in adventure
player s_t5nk_fe1n23 spawn in adventure
player n3kop5rr0t spawn in adventure