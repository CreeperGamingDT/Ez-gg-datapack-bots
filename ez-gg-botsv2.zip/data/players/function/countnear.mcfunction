scoreboard players set @s team1indcount 0
execute if score @s hit_cooldown matches ..1 run scoreboard players add @s team1indcount 3
execute as @a[tag=team1,distance=0.01..5] run scoreboard players add @s team1indcount 1