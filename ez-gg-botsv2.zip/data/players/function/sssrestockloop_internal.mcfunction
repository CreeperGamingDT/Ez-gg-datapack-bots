scoreboard players operation @s restockloopdelay -= one one

item replace entity @s[tag=!iron] hotbar.6 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:long_strength"}] 1
item replace entity @s[tag=!iron] hotbar.7 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:long_swiftness"}] 1
execute unless items entity @s hotbar.8 bow run item replace entity @s[tag=!iron] hotbar.8 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:long_fire_resistance"}] 1

#item replace entity @s[tag=cart_blastprot] hotbar.6 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_strength"}] 1
#item replace entity @s[tag=mikearmyR1] hotbar.6 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_strength"}] 1
#item replace entity @s[tag=cart_blastprot] hotbar.7 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_swiftness"}] 1
#item replace entity @s[tag=mikearmyR1] hotbar.7 with minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:strong_swiftness"}] 1

item replace entity @s[tag=!iron] hotbar.3 with wind_charge 64
item replace entity @s[tag=!iron] hotbar.2 with ender_pearl 16