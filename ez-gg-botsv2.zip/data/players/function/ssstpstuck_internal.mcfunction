scoreboard objectives add playerposX dummy
scoreboard objectives add playerposZ dummy

execute store result score pos playerposX run data get entity @s Pos[0] 1000
execute store result score pos playerposZ run data get entity @s Pos[2] 1000

#execute as @a[tag=team1] at @s unless block ~ ~-0.9 ~ #replaceable if data entity @s {SelectedItem:{id:"minecraft:wind_charge"}} run spreadplayers ~ ~ 0 1 false @s


summon armor_stand ~ ~ ~ {Tags:["temp"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

spreadplayers ~ ~ 0 1 false @e[tag=temp,limit=1]

execute store result entity @e[tag=temp,limit=1] Pos[0] double 0.001 run scoreboard players get pos playerposX
execute store result entity @e[tag=temp,limit=1] Pos[2] double 0.001 run scoreboard players get pos playerposZ
execute if entity @p[tag=!team1,distance=15..] at @s run tp @s @e[tag=temp,limit=1]

kill @e[tag=temp]