#do before run
execute as @a[tag=team1] at @s run function players:hitcooldown
function players:detectsurvival

execute as @a[scores={waterplacedelay=0..},tag=team1] at @s run scoreboard players operation @s waterplacedelay -= one one
execute as @a[scores={cart_cooldown=0..},tag=team1] at @s run scoreboard players operation @s cart_cooldown -= one one
execute as @a[scores={waterplacedelay=..-1},tag=team1,nbt={Inventory:[{Slot:4b,id:"minecraft:water_bucket"}]}] at @s run scoreboard players set @s waterplacedelay 100

execute as @a store result score @s y_velocity run data get entity @s Motion[1] 1000

tag @a[tag=team1] remove walk
tag @a[tag=team1] remove crit
tag @a[tag=team1] remove gap
tag @a[tag=team1] remove sprintjump
tag @a[tag=team1] remove waterjump
tag @a[tag=team1] remove watersneak
tag @a[tag=team1] remove inwater
tag @a[tag=team1] remove hitcooldown
tag @a[tag=team1] remove strafe
tag @a[tag=team1] remove combohit
tag @a[tag=team1] remove pot
tag @a[tag=team1] remove inweb
tag @a[tag=team1] remove inwebPP
tag @a[tag=team1] remove inwebNP
tag @a[tag=team1] remove inwebNN
tag @a[tag=team1] remove inwebPN
tag @a[tag=team1] remove inwebfull
tag @a[tag=team1] remove pearl
tag @a[tag=team1] remove haswater
tag @a[tag=team1] remove backward

tag @a[tag=team1] remove upmace
tag @a[tag=team1] remove hitmace
tag @a[tag=team1] remove gapscared

#countnear
execute as @a[tag=team1] at @s run function players:countnear

#kill endermite
kill @e[type=endermite]

#setting up for loop

#i
scoreboard players set i idx 0
#len
execute store result score len idx run data get storage ez-gg:playerstorage players
#temp array
data modify storage ez-gg:playerstorage temp.players set from storage ez-gg:playerstorage players

#set output
data modify storage ez-gg:playerstorage ctx.forloop.run set value "regular:_prerun"

function players:iteration with storage ez-gg:playerstorage ctx.forloop




#loop
schedule function players:aaloop 1t replace