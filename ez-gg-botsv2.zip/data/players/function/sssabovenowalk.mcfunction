scoreboard objectives add playerposY dummy

execute store result score pos playerposY run data get entity @p[tag=target] Pos[1] 1000

summon armor_stand ~ ~ ~ {Tags:["temp"],NoGravity:1b,Marker:1b,Invincible:1b}

execute store result entity @e[tag=temp,limit=1] Pos[1] double 0.001 run scoreboard players get pos playerposY

tag @s add tempP

execute as @e[tag=temp,limit=1] at @s if entity @p[tag=tempP,distance=1..] if items entity @p[tag=target,distance=..5,scores={y_velocity=800..}] hotbar.* mace unless entity @p[tag=follow] run tag @p[tag=tempP] add waitHeAbove
execute as @p[tag=tempP] if entity @s[tag=waitHeAbove] if entity @p[tag=target,scores={y_velocity=..800}] run tag @s add runHeIS
#
#execute as @p[tag=tempP] if entity @s[tag=waitHeAbove] run say waitHeAbove

execute as @e[tag=temp,limit=1] at @s if entity @p[tag=target,distance=8..] run tag @p[tag=tempP] remove runHeIS
execute as @e[tag=temp,limit=1] at @s if entity @p[tag=target,distance=8..] run tag @p[tag=tempP] remove waitHeAbove
execute if entity @p[tag=target,scores={y_velocity=-79}] run tag @p[tag=tempP] remove runHeIS
execute if entity @p[tag=target,scores={y_velocity=-79}] run tag @p[tag=tempP] remove waitHeAbove
execute if entity @p[tag=target,scores={y_velocity=..-800}] run tag @p[tag=tempP] remove runHeIS
execute if entity @p[tag=target,scores={y_velocity=..-800}] run tag @p[tag=tempP] remove waitHeAbove
#execute if entity @p[tag=target,scores={y_velocity=..-800}] run say rem

execute as @p[tag=tempP] if entity @s[tag=runHeIS] run tag @s remove sprintjump
execute as @p[tag=tempP] if entity @s[tag=runHeIS] run tag @s remove walk
#execute as @p[tag=tempP] if entity @s[tag=runHeIS] run tag @s remove gap
execute as @p[tag=tempP] if entity @s[tag=runHeIS] run tag @s add backward 
execute as @p[tag=tempP] if entity @s[tag=runHeIS] as @e[tag=temp,limit=1] at @s if entity @p[tag=target,distance=1..] run tag @s add strafe
#execute as @p[tag=tempP] if entity @s[tag=runHeIS] run say runHeIS 

#jump if block
execute as @p[tag=tempP] if entity @s[tag=runHeIS] run summon armor_stand ~ ~ ~ {Tags:["yawonly"],NoGravity:1b,Marker:1b,Invisible:1b,Invincible:1b}

execute as @p[tag=tempP] if entity @s[tag=runHeIS] store result entity @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] Rotation[0] float 1 run data get entity @s Rotation[0]

execute as @p[tag=tempP] if entity @s[tag=runHeIS] as @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly] at @s unless block ^ ^ ^-0.4 #replaceable unless block ^ ^ ^-0.5 #replaceable run tag @p[tag=tempP] add sprintjump


kill @e[tag=temp]
kill @e[type=armor_stand,limit=1,sort=nearest,tag=yawonly]

tag @p[tag=tempP] remove tempP